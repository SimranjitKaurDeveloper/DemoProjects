-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2018 at 04:11 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simtestapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_desc` varchar(255) NOT NULL,
  `p_price` float NOT NULL,
  `p_image` varchar(255) NOT NULL,
  `p_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `p_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `p_name`, `p_desc`, `p_price`, `p_image`, `p_created`, `p_updated`) VALUES
(1, 'Chocolate Hershey Syrup', 'Ut laoreet diam ac sapien ultrices aliquam. Integer rhoncus nibh libero, sed facilisis mauris cursus eu. Nulla tincidunt euismod finibus. In non mi ultrices, pulvinar lectus a, mattis elit. Etiam mollis lorem leo, dapibus tincidunt nibh elementum porttito', 3.5, 'hershey.png', '2018-11-26 02:57:05', '2018-11-26 02:57:05'),
(2, 'Bulla IceCreeam Vanilla', 'Donec sit amet lorem non dui aliquam efficitur. Phasellus lobortis odio lorem, id sollicitudin eros lacinia non. Integer vitae consequat purus. Fusce quis felis volutpat, gravida lorem in, laoreet tortor.', 6.5, 'Bulla_Vanila_IceCream.jpg', '2018-11-26 03:05:13', '2018-11-26 03:05:13'),
(3, 'Iced Coffee', 'Aliquam sit amet risus ullamcorper, iaculis urna ac, rhoncus ante. Vivamus a ante neque. Pellentesque suscipit sagittis lorem, in sagittis nulla aliquet eu.', 3.5, 'cfmoove.jpg', '2018-11-26 03:05:42', '2018-11-26 03:05:42'),
(4, 'Chocolate Moove Milk', 'Aliquam sit amet risus ullamcorper, iaculis urna ac, rhoncus ante. Vivamus a ante neque. Pellentesque suscipit sagittis lorem, in sagittis nulla aliquet eu.', 2.5, 'cmoove4.jpg', '2018-11-26 03:06:21', '2018-11-26 03:06:21'),
(5, 'Chocolate Hershey Syrup', 'Aliquam sit amet risus ullamcorper, iaculis urna ac, rhoncus ante. Vivamus a ante neque. Pellentesque suscipit sagittis lorem, in sagittis nulla aliquet eu.', 5.6, 'hershey.png', '2018-11-26 03:06:41', '2018-11-26 03:06:41'),
(6, 'OriginalIceCream_Vanilla', 'Aliquam sit amet risus ullamcorper, iaculis urna ac, rhoncus ante. Vivamus a ante neque. Pellentesque suscipit sagittis lorem, in sagittis nulla aliquet eu.', 6.7, 'O_icecream_vanilla.jpg', '2018-11-26 03:07:03', '2018-11-26 03:07:03'),
(7, 'Nutella', 'Maecenas interdum eu nulla ac consectetur. Duis sed massa quis odio lacinia interdum. Aenean vestibulum feugiat aliquam. Duis posuere urna vel libero lacinia, commodo commodo velit venenatis. Donec sit amet lorem non dui aliquam efficitur. Phasellus lobor', 7, 'nutella.jpg', '2018-11-26 03:07:34', '2018-11-26 03:07:34'),
(8, 'Moove Banana milk', 'Maecenas interdum eu nulla ac consectetur. Duis sed massa quis odio lacinia interdum. Aenean vestibulum feugiat aliquam. Duis posuere urna vel libero lacinia, commodo commodo velit venenatis. Donec sit amet lorem non dui aliquam efficitur. Phasellus lobor', 3, 'smoove.jpg', '2018-11-26 03:08:24', '2018-11-26 03:08:24'),
(9, 'Chocolate Moove Milk', 'Quisque eu feugiat odio. Proin accumsan massa vitae sapien ullamcorper ultricies sed ac odio. Donec ac enim ipsum. Duis ultrices quam nisl. ', 2, 'smoove3.jpg', '2018-11-26 03:08:59', '2018-11-26 03:08:59'),
(10, 'Oak Chocolate Milk', 'Quisque eu feugiat odio. Proin accumsan massa vitae sapien ullamcorper ultricies sed ac odio. Donec ac enim ipsum. Duis ultrices quam nisl. ', 2.6, 'oak_choco.jpg', '2018-11-26 03:10:14', '2018-11-26 03:10:14'),
(11, 'Original IceCream Strawberry', 'Aliquam sit amet risus ullamcorper, iaculis urna ac, rhoncus ante. Vivamus a ante neque. Pellentesque suscipit sagittis lorem, in sagittis nulla aliquet eu.', 6, 'Original_IceCream_strwaberry.jpg', '2018-11-26 03:10:56', '2018-11-26 03:10:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
