<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Product Entity
 *
 * @property int $id
 * @property string $p_name
 * @property string $p_desc
 * @property float $p_price
 * @property string $p_image
 * @property \Cake\I18n\FrozenTime $p_created
 * @property \Cake\I18n\FrozenTime|null $p_updated
 */
class Product extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'p_name' => true,
        'p_desc' => true,
        'p_price' => true,
        'p_image' => true,
        'p_created' => true,
        'p_updated' => true
    ];
}
