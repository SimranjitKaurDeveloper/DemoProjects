<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Products Model
 *
 * @method \App\Model\Entity\Product get($primaryKey, $options = [])
 * @method \App\Model\Entity\Product newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Product[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Product|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Product|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Product patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Product[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Product findOrCreate($search, callable $callback = null, $options = [])
 */
class ProductsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('products');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('p_name')
            ->maxLength('p_name', 255)
            ->requirePresence('p_name', 'create')
            ->notEmpty('p_name');

        $validator
            ->scalar('p_desc')
            ->maxLength('p_desc', 255)
            ->requirePresence('p_desc', 'create')
            ->notEmpty('p_desc');

        $validator
            ->numeric('p_price')
            ->requirePresence('p_price', 'create')
            ->notEmpty('p_price');

        /*$validator
            //->scalar('p_image')
            //->maxLength('p_image', 255)
            //->requirePresence('p_image', 'create')
            ->notEmpty('p_image');
          */
        $validator
            ->notEmpty('p_image')
            ->add('p_image', [
                   'validExtension' => [
                       'rule' => ['extension',['png','jpeg','jpg','gif']],
                       'message' => __('These files extension are allowed: jpg, jpeg, gif, png')
                   ]
                 ]);

        $validator
            ->allowEmpty('p_image_2')
            ->add('p_image_2', [
                'validExtension' => [
                    'rule' => ['extension',['png','jpeg','jpg','gif']],
                    'message' => __('These files extension are allowed: jpg, jpeg, gif, png')
                ]
              ]);

      /*  $validator
            ->dateTime('p_created')
            ->requirePresence('p_created', 'create')
            ->notEmpty('p_created');

        $validator
            ->dateTime('p_updated')
            ->allowEmpty('p_updated');*/

        return $validator;
    }
}
