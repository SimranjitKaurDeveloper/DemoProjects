<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class products extends CI_Controller {
	private $categoriesList = null;
	private $locationsList = null;
	private $storesList = null;
	public $productUnitOption = array('l' => 'Liter(L)', 'ml' => 'Milliliter(ml)', 'kg' => 'Kilogram(Kg)', 'g' => 'Gram(g)', 'each' => 'Each', 'pack' => 'Pack');
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		//$this->load->database();
		$this->load->library('ion_auth');
		$this->load->model('products_model');
		$this->load->helper('url');

		$this->categoriesList = $this->products_model->get_categories();
		$this->locationsList = $this->products_model->get_locations();
		$this->storesList = $this->products_model->get_stores();

		/*if ($this->ion_auth->logged_in())
		{	$user = $this->ion_auth->user()->row();
		}else{
			$user = '';
		}*/
		if ($this->ion_auth->logged_in())
		{	$this->userID = $this->ion_auth->get_user_id();
		}else{
			$this->userID = 0;
		}

	}



/*
************************
*********INDEX
************************
*/
	public function index()
	{


		$data = array();
		$data = array('viewName' => 'product/index','leftSidebar' => 'product/left_searchbar','userID' => $this->userID);
		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);

		//?search_item=juice&search_loc=parramatta&search=1
		if(isset($_GET['sitem']) && $_GET['sitem'] !=''){	$tag = $_GET['sitem'];
		}else{	$tag = '';
		}

		if(isset($_GET['sloc']) && $_GET['sloc'] !=''){	$loc = $_GET['sloc'];
		}else{ $loc ='';
		}

		if(isset($_GET['scat']) && $_GET['scat'] !=''){	$cat = $_GET['scat'];
		}else{	$cat = '';}

		if(isset($_GET['sstore']) && $_GET['sstore'] !=''){	$store = $_GET['sstore'];
		}else{	$store = '';}


		//if($tag != '' && $loc !=''){
			$sdata = array('stag' => $tag, 'sloc' => $loc, 'scat' => $cat, 'sstore' => $store);
			$productsList =  $this->products_model->searchData($sdata);
		/*}else{
			$productsList =  $this->products_model->getStoreProducts();
		}*/

		$data += array('products' => $productsList);
		$data += array('search'=> $sdata);
		$data += array('current_params'=> $_SERVER['QUERY_STRING']);
		//echo'<pre>';print_r($data);die;
		$this->load->view('templates/content',$data);

	}



/*
************************
*********CREATE PRODUCT and STORE PRODUCT
************************
*/

	//Create product
	public function create()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$userID = $this->ion_auth->get_user_id();


		$data = array();
		$data = array('title' => 'Create a Product', 'viewName' => 'product/create','leftSidebar' => 'product/left_sidebar','message' =>'');

		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);

		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->form_validation->set_rules('productname', 'Name', 'required');
		$this->form_validation->set_rules('productdesc', 'Description', 'required');
		$this->form_validation->set_rules('productprice', 'Price', 'required');
		$this->form_validation->set_rules('productquantity', 'Quantity', 'required');
		$this->form_validation->set_rules('productunit', 'Unit', 'required');
		$this->form_validation->set_rules('productcategory', 'Category', 'required');
		$this->form_validation->set_rules('productlocation', 'Location', 'required');
		$this->form_validation->set_rules('productstore', 'Store', 'required');


		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('templates/content',$data);
		}
		else
		{
			$p_name		= $this->input->post('productname');
			$p_des		= $this->input->post('productdesc');
			$p_price	= $this->input->post('productprice');
			$p_qty		= $this->input->post('productquantity');
			$p_unit		= $this->input->post('productunit');
			$p_tags		= $this->input->post('producttag');
			$p_catId	= $this->input->post('productcategory');
			$p_storeId  = $this->input->post('productstore');
			$p_locId    = $this->input->post('productlocation');
			//echo '<pre>';print_r($_FILES);die;
			$p_image	= '';
			if(isset($_FILES["itemImage"]["tmp_name"])){
				$img = $this->do_upload();
				if($img){
						$p_image	= $img;
				}
			}
			//$p_createData	= date();

			if($p_unit == 'L' or $p_unit == 'ml'){	$p_bunit = 'L';
			}elseif($p_unit == 'Kg' or $p_unit == 'g'){	$p_bunit = 'Kg';
			}elseif($p_unit == 'Each' or $p_unit == 'pack'){	$p_bunit = 'Each';
			}else{	$p_bunit = '';
			}


			if($p_unit == 'ml' or $p_unit == 'g'){	$p_baseprice = ($p_price)/($p_qty/1000);
			}elseif($p_unit == 'L' or $p_unit == 'Kg' or $p_unit == 'pack'){	$p_baseprice = $p_price/$p_qty;
			}elseif($p_unit == 'Each'){	$p_baseprice = $p_price;
			}else{	$p_baseprice = '';
			}


			$addDataSet = array(
			'name'			=> $p_name,
			'description'	=> $p_des,
			'cat_id'		=> $p_catId,
			'base_qty'		=> 1,
			'base_unit'		=> $p_bunit,
			'tags'			=> $p_tags,
			'image'			=> $p_image
			//'created_date'	=> $p_createData,$this->db->set('date_field_name', 'NOW()', FALSE); or $now = date('Y-m-d H:i:s');
			//'modified_date' => $p_modifiedDate
			);
			$message = '';
			$addData = $this->products_model->adddata($addDataSet);
			if($addData){
				$message .= 'Product';

				$addStoreProdSet = array(
				'user_id'		=> $userID,
				'loc_id'		=> $p_locId,
				'store_id'		=> $p_storeId,
				'product_id'	=> $addData,
				'price'			=> $p_price,
				'quantity'		=> $p_qty,
				'unit'			=> $p_unit,
				'pbase_price'	=> $p_baseprice

				);
				$addStoreProduct = $this->products_model->addStoreProduct($addStoreProdSet);
				//print_r($addStoreProdSet);die;
				if($addStoreProduct){
					$message .= ' and Store Product';
				}
				$message .= ' is added successfully';
				$data['message'] = $message;
			}
			$this->load->view('templates/content',$data);
		}
	}

	private function do_upload()
	{
		$url = "";
 //echo '<pre>';print_r($_FILES);die;
		if(is_uploaded_file($_FILES["itemImage"]["tmp_name"]))
		{
			$type = explode(".",$_FILES["itemImage"]["name"]);
			if(in_array($type[1],array("jpg","jepg","png","gif"))){
				$url = "./images/products/".$_FILES["itemImage"]["name"];
				if(move_uploaded_file($_FILES["itemImage"]["tmp_name"],$url)){
					return $_FILES["itemImage"]["name"];
				}
			}

		}
		return false;

	}

/*
*******************************************
********* PRODUCTS********************
*******************************************
*/
/*
************************
*********PRODUCT UPDATE
************************
*/
	public function product_update()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$userID = $this->ion_auth->get_user_id();
		$result = [];

		$prodId = $this->input->post('productid');
		$p_name		= $this->input->post('productname');
		$p_des		= $this->input->post('productdesc');
		$p_qty		= $this->input->post('productquantity');
		$p_unit		= $this->input->post('productunit');
		$p_tags		= $this->input->post('producttag');
		$p_catId	= $this->input->post('productcategory');

		if($p_unit == 'L' or $p_unit == 'ml'){	$p_bunit = 'L';
		}elseif($p_unit == 'Kg' or $p_unit == 'g'){	$p_bunit = 'Kg';
		}elseif($p_unit == 'Each' or $p_unit == 'pack'){	$p_bunit = 'Each';
		}else{	$p_bunit = '';
		}


		$editDataSet = array(
			'name'			=> $p_name,
			'description'	=> $p_des,
			'cat_id'		=> $p_catId,
			'base_qty'		=> 1,
			'base_unit'		=> $p_bunit,
			'tags'			=> $p_tags
		);
		$message = '';
		$editData = $this->products_model->product_update(array('id' => $prodId), $editDataSet);

		if($editData){	echo json_encode(array("status" => TRUE, 'result' => $result));
		}else{	echo json_encode(array("status" => FALSE, 'result' => $result, 'error' => 'Product not updated'));
		}

	}


/*
************************
********* DELETE PRODUCT
************************
*/

	//Product delete
	public function product_delete($id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$this->products_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}





/*
*******************************************
*********STORE PRODUCTS********************
*******************************************
*/

/*
************************
*********UPDATE STORE PRODUCT
************************
*/

	//Product Update
	public function storeproduct_update()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$userID = $this->ion_auth->get_user_id();
		$result = [];
		//$result[] = $this->input->post('productunit');

		/*$editDataSet = array(
			'name' => $this->input->post('productname'),
			'description' =>  $this->input->post('productdesc'),
			'price' =>  $this->input->post('productprice'),
			'quantity' => $this->input->post('productqty'),
			'units' => $this->input->post('productunit'),
			'tags' => $this->input->post('producttag'),
			'cat_id' => $this->input->post('productcategory'),
			'store_id' => $this->input->post('productstore'),
			'loc_id' => $this->input->post('productlocation'),
			);
		$data = $this->products_model->product_update(array('id' => $this->input->post('productid')), $editDataSet);
		*/

			$prodId = $this->input->post('productid');
			$storeProdId = $this->input->post('store_productid');

			$p_price	= $this->input->post('productprice');
			$p_qty		= $this->input->post('productquantity');
			$p_unit		= $this->input->post('productunit');
			$p_tags		= $this->input->post('producttag');
			$p_storeId  = $this->input->post('productstore');
			$p_locId    = $this->input->post('productlocation');
		//	$p_des		= $this->input->post('productdesc');

			if($p_unit == 'ml' or $p_unit == 'g'){	$p_baseprice = ($p_price)/($p_qty/1000);
			}elseif($p_unit == 'L' or $p_unit == 'Kg' or $p_unit == 'pack'){	$p_baseprice = $p_price/$p_qty;
			}elseif($p_unit == 'Each'){	$p_baseprice = $p_price;
			}else{	$p_baseprice = '';
			}


			$editDataSet = array(
			//'description'	=> $p_des,
			'tags'	=> $p_tags
			);
			$message = '';
			$editData = $this->products_model->product_update(array('id' => $prodId), $editDataSet);

			if($editData){
				if($storeProdId != ''){
						$editStoreProdSet = array(
							'user_id'		=> $userID,
							'loc_id'		=> $p_locId,
							'store_id'		=> $p_storeId,
							'price'			=> $p_price,
							'quantity'		=> $p_qty,
							'unit'			=> $p_unit,
							'pbase_price'	=> $p_baseprice,
							'modified_date' => NOW()
						);
						$editStoreProduct = $this->products_model->storeproduct_update(array('sp_id' => $storeProdId), $editStoreProdSet);
						if($editStoreProduct){ echo json_encode(array("status" => TRUE, 'result' => $result, 'message' => 'Storeproduct updated successfully'));
						}else{ echo json_encode(array("status" => FALSE, 'result' => $result, 'error' => 'StoreProduct not updated'));
						}
					}else{
						$addStoreProdSet = array(
						'user_id'		=> $userID,
						'loc_id'		=> $p_locId,
						'store_id'		=> $p_storeId,
						'product_id'	=> $editData,
						'price'			=> $p_price,
						'quantity'		=> $p_qty,
						'unit'			=> $p_unit,
						'pbase_price'	=> $p_baseprice

						);
						$addStoreProduct = $this->products_model->addStoreProduct($addStoreProdSet);
						if($addStoreProduct){  echo json_encode(array("status" => TRUE, 'result' => $result,'message' => 'Storeproduct added'));
						}else{ echo json_encode(array("status" => FALSE, 'result' => $result, 'error' => 'StoreProduct not added'));
						}

					}
			}else{	echo json_encode(array("status" => FALSE, 'result' => $result, 'error' => 'Product not updated'));
			}


		//echo json_encode(array("status" => TRUE));
	}

/*
************************
********* DELETE STORE PRODUCT
************************
*/

	//Product delete
	public function storeproduct_delete($id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$this->products_model->deleteStoreProduct_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

/*
************************
*********VIEW ALL STORE PRODUCT
************************
*/
	public function store_products($id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$data = array();
		$data = array('viewName' => 'product/store_products','leftSidebar' => 'product/left_sidebar');

		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);


		$data += array('products'=> $this->products_model->getStoreProductsByPid($id));
		//echo '<pre>';print_r($data);die;
		$this->load->view('templates/content',$data);

	}


/*
************************
*********VIEWALL PRODUCTS
************************
*/
	public function listing()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$data = array();
		$data = array('viewName' => 'product/listing','leftSidebar' => 'product/left_sidebar');

		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);


		$data += array('products'=> $this->products_model->getproducts());
		//echo '<pre>';print_r($data);die;
		$this->load->view('templates/content',$data);

	}
/*
************************
*********VIEW PRODUCT
************************
*/
	public function view($id)
	{
		$data = array();

		$data = array('viewName' => 'product/view','leftSidebar' => 'product/left_locsearchbar','userID' => $this->userID);

		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);

		if(isset($_GET['sitem']) && $_GET['sitem'] !=''){	$tag = $_GET['sitem'];
		}else{	$tag = '';
		}

		if(isset($_GET['sloc']) && $_GET['sloc'] !=''){	$loc = $_GET['sloc'];
		}else{ $loc ='';
		}

		if(isset($_GET['scat']) && $_GET['scat'] !=''){	$cat = $_GET['scat'];
		}else{	$cat = '';}

		if(isset($_GET['sstore']) && $_GET['sstore'] !=''){	$store = $_GET['sstore'];
		}else{	$store = '';}


		$sdata = array('stag' => $tag, 'sloc' => $loc, 'scat' => $cat, 'sstore' => $store);
		$data += array('search' => $sdata);

		$data['product'] = $this->products_model->getStoreProducts($id);
		$data['cheaperProd'] = $this->products_model->get_cheaper_product($data['product'],$data['search']);


		$this->load->view('templates/content',$data);
	}


/*
*******************************************
*********AJAX******************************
*******************************************
*/

/*
************************
*********AJAX EDIT
************************
*/
	//Product Edit
	public function ajax_edit($dataType,$id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		if($dataType == 'storeProd'){
			$data = $this->products_model->getStoreProducts($id);
		}elseif($dataType == 'product'){	$data = $this->products_model->getproducts($id);
		}else{ $data = [];
		}
		$data = json_encode($data);
		echo $data;
	}

	//AUTOCOMPLETE
	public function ajax_showSuggestions($value){

        $data=$this->products_model->getProductsId($value);
        echo json_encode($data);

	}
	public function showSuggestions(){
		$term = $this->input->post('term', TRUE);
        $data=$this->products_model->getProductsId($term);
        echo json_encode($data);

	}



/*
*******************************************
*************WISHLIST**************************
*******************************************
*/

/*
************************
*********VIEW WISHLIST
************************
*/
	public function wishlist()
	{
		if (!$this->ion_auth->logged_in())
		{	redirect('/auth/login', 'refresh');
		}
		$data = array();

		$data = array('viewName' => 'product/wishlist','leftSidebar' => 'product/left_sidebar');
		$data['products'] = $this->products_model->getwishlistdata();
		$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);
		$this->load->view('templates/content',$data);

	}

/*
************************
*********ADD WISHLIST
************************
*/

	public function addToWishlist($id)
	{
						$wishlist = $this->products_model->get_wishlist_by_pid($id,$this->userID);

						if(!empty($wishlist)){
							echo json_encode(array("status" => 'failure'));
						}else{

							$newWishlist = array(
								'storeproduct_id' => $id,
								'user_id' => $this->userID

								);
							$addToWishlist = $this->products_model->addtowishlistdata($newWishlist);
							//print_r($addToWishlist);
							if($addToWishlist){
								//$addToWishlist = json_encode($addToWishlist);
								//echo $addToWishlist;
								echo json_encode(array("status" => 'success'));
							}else{
								echo json_encode(array("status" => 'false'));
							}

						}


	}

/*
************************
*********DELETE WISHLIST
************************
*/

	public function removeFromWishlist($id)
	{

		$wishlist = $this->products_model->get_wishlist_by_id($id);
		if($wishlist)
		{

			$result = $this->products_model->removefromwishlistdata($id);
			//print_r($addToWishlist);
			if($result){
				//$addToWishlist = json_encode($addToWishlist);
				//echo $addToWishlist;
				echo json_encode(array("status" => 'success'));
			}else{
				echo json_encode(array("status" => 'failure'));
			}

		}else{
			echo json_encode(array("status" => FALSE));
		}
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
