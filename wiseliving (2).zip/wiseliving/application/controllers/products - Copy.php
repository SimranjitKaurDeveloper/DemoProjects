<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class products extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		//$this->load->database();
		$this->load->library('ion_auth');
		$this->load->model('products_model');
		$this->load->helper('url');
		
	}


	public function index()
	{
		$data = array();
		$data = array('viewName' => 'product/index','leftSidebar' => 'product/left_sidebar');
		$data['products'] = $this->products_model->getdata();
		//print_r($data);die;
		$this->load->view('templates/content',$data);

	}

	//Create product
	public function create()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}

		$data = array();
		$data = array('title' => 'Create a Product', 'viewName' => 'product/create','leftSidebar' => 'product/left_sidebar','message' => '');

		$this->load->helper('form');
		$this->load->library('form_validation');

		$this->form_validation->set_rules('productname', 'Name', 'required');
		$this->form_validation->set_rules('productdesc', 'Description', 'required');
		$this->form_validation->set_rules('productprice', 'Price', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('templates/content',$data);
		}
		else
		{
			$addData = $this->products_model->adddata();
			if($addData){
				$data['message'] = 'Product is added successfully';
			}
			$this->load->view('templates/content',$data);
		}
	}


	//Product Edit
	public function ajax_edit($id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}

		$data = $this->products_model->get_by_id($id);
		$data = json_encode($data);
		echo $data;
	}

	//Product Update
	public function product_update()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		
		$data = array(
				'code' => $this->input->post('productcode'),
				'name' => $this->input->post('productname'),
				'description' => $this->input->post('productdesc'),
				'price' => $this->input->post('productprice'),
				'quantity' => $this->input->post('productqty'),
				'units' => $this->input->post('productunit'),


			);
		$data = $this->products_model->product_update(array('id' => $this->input->post('productid')), $data);
		echo json_encode(array("status" => TRUE));
	}

	//Product delete
	public function product_delete($id)
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
		{	redirect('/', 'refresh');
		}
		$this->products_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



	public function listing()
	{

		$data = array();
		$data = array('viewName' => 'product/listing','leftSidebar' => 'product/left_sidebar');
		$data['products'] = $this->products_model->getdata();
		$this->load->view('templates/content',$data);

	}
	public function wishlist()
	{
		$data = array();
		$data = array('viewName' => 'product/wishlist','leftSidebar' => 'product/left_sidebar');
		$data['products'] = $this->products_model->getwishlistdata();
		$this->load->view('templates/content',$data);

	}

	public function view($id)
	{
		$data = array();

			$data = array('viewName' => 'product/view','leftSidebar' => 'product/left_sidebar');
			$data['product'] = $this->products_model->get_by_id($id);

		$this->load->view('templates/content',$data);
	}

	public function addToWishlist($id)
	{
		
		$wishlist = $this->products_model->get_wishlist_by_pid($id);
		if($wishlist)
		{
			echo json_encode(array("status" => FALSE));
		}
		else
		{
			$data = $this->products_model->get_by_id($id);
			$newWishlist = array(
				'product_id' => $data->id
					/*'productcode' => $data->code,
					'productname' => $data->name,
					'productdesc' => $data->description,
					'productprice' => $data->price,
					'productunit' => $data->units*/
				);
			$addToWishlist = $this->products_model->addtowishlistdata($newWishlist);
			//print_r($addToWishlist);
			if($addToWishlist){
				//$addToWishlist = json_encode($addToWishlist);
				//echo $addToWishlist;
				echo json_encode(array("status" => 'success'));
			}else{
				echo json_encode(array("status" => 'failure'));
			}
			
		}

	}

	public function removeFromWishlist($id)
	{
		
		$wishlist = $this->products_model->get_wishlist_by_id($id);
		if($wishlist)
		{
			
			$result = $this->products_model->removefromwishlistdata($id);
			//print_r($addToWishlist);
			if($result){
				//$addToWishlist = json_encode($addToWishlist);
				//echo $addToWishlist;
				echo json_encode(array("status" => 'success'));
			}else{
				echo json_encode(array("status" => 'failure'));
			}
			
		}else{
			echo json_encode(array("status" => FALSE));
		}
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
