
		<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library(array('ion_auth','session'));
		$this->load->helper(array('url', 'language'));


	}



    public function index()
    {
				$this->load->helper('form');
        $this->load->library('form_validation');
				$data = array('viewName' => 'register/index');
        $this->form_validation->set_rules('first_name', 'First name','trim|required');
        $this->form_validation->set_rules('last_name', 'Last name','trim|required');
        $this->form_validation->set_rules('username','Username','trim|required|is_unique[users.username]');
        $this->form_validation->set_rules('email','Email','trim|valid_email|required|is_unique[users.email]');
        $this->form_validation->set_rules('password','Password','trim|min_length[8]|max_length[20]|required');
        $this->form_validation->set_rules('confirm_password','Confirm password','trim|matches[password]|required');

        if($this->form_validation->run()===FALSE)
        {
          //  $this->load->helper('form');
						$this->load->view('templates/content',$data);
						//$this->load->view('register/index');

        }
        else
        {
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $additional_data = array(
                'first_name' => $first_name,
                'last_name' => $last_name
            );
						$group = array('4');
          //  $this->load->library('ion_auth');
            if($this->ion_auth->register($username,$password,$email,$additional_data,$group))
            {
              //  $_SESSION['auth_message'] = 'The account has been created. You may now login.';
                $this->session->set_flashdata('message', $this->ion_auth->messages());
                redirect('auth/login');
            }
            else
            {
              	$this->session->set_flashdata('message', $this->ion_auth->errors());

                redirect('register');
            }
        }
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
