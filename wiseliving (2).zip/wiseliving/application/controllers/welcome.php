<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		//$this->load->database();
		$this->load->helper('url');

		redirect('/products', 'refresh');
		/*
		$this->load->library('ion_auth');
		$this->load->model('products_model');
	

		$this->categoriesList = $this->products_model->get_categories();
		$this->locationsList = $this->products_model->get_locations();
		$this->storesList = $this->products_model->get_stores();
		*/
		
		
	}


	public function index()
	{	
		//$this->load->view('welcome_message');
		$data = array();
		$data = array('viewName' => 'product/index','leftSidebar' => 'product/left_sidebar');
		$data['products'] = $this->products_model->getStoreProducts();

				$data += array('categories' => $this->categoriesList);
		$data += array('locations' => $this->locationsList);
		$data += array('stores' => $this->storesList);

		//print_r($data);die;
		$this->load->view('templates/content',$data);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */