<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ion_auth extends CI_Controller {

	function __construct() {
		parent::__construct();
	
		//  Path to simple_html_dom
		include APPPATH . 'third_party/ion_auth/controllers/Auth.php';
		
	}
}
