<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class products_model extends CI_Model {

	public function __construct()
	{
		$this->load->database();
		if($this->ion_auth->logged_in()){	$this->userID = $this->ion_auth->user()->row()->id;}
	}

/*
************************
*********GET PRODUCT
************************
*/

	//Add the following code to your model.

	public function getproducts($id = FALSE)
	{	$this->db->select('p.*,p.id as pid');
		//$this->db->select('p.*','w.*');
		$this->db->from('products as p');
		//$this->db->join('wishlists as w', 'w.product_id = p.id','left');
		//$this->db->join('store_products as sp', 'sp.product_id = p.id','left');

		if($id){
			$this->db->where('p.id', $id);
			$query = $this->db->get();
			return $query->row();
		}else{
			$query = $this->db->get();
			$data = $query->result();
			foreach($data as $value){
				$resultSet[$value->pid] = $value;
			}
			//print_r($resultSet);die;
			return $resultSet;
		}

	}


/*
************************
*********ADD PRODUCT
************************
*/

	public function adddata($data)
	{
		$this->load->helper('url');
		$savedata = $this->db->insert('products', $data);
		$insert_id = $this->db->insert_id();

		return  $insert_id;
	    //return $savedata;
	}

/*
************************
*********UPDATE PRODUCT
************************
*/

	public function product_update($where, $data)
	{
		//$this->db->update('products', $data, $where);
		/*$this->db->where('id', $id);
		$this->db->update('products', $data);
		if($this->db->update('products')){
			return '1001';
		}else{ return '1002';
		}*/
		//return $this->db->affected_rows();
		return $this->db->update('products', $data, $where);

	}

/*
************************
*********DELETE PRODUCT
************************
*/
	public function delete_by_id($id)
	{
		//FIRST DELETE ALL RELATED STRORE PROD
		$this->db->where('product_id', $id);
		$deleted = $this->db->delete('store_products');
		if($deleted){
			$this->db->where('id', $id);
			$this->db->delete('products');
		}
	}


/*
************************
*********ADD STORE PRODUCT
************************
*/

	public function addStoreProduct($data)
	{
		$this->load->helper('url');
		$savedata = $this->db->insert('store_products', $data);
	    $insert_id = $this->db->insert_id();

		return  $insert_id;
	}

/*
************************
*********UPDATE STORE PRODUCT
************************
*/

	public function storeproduct_update($where, $data)
	{
		return $this->db->update('store_products', $data, $where);
		//return $this->db->affected_rows();
	}
/*
************************
*********DELETE STORE PRODUCT
************************
*/
	public function deleteStoreProduct_by_id($id)
	{
		$this->db->where('sp_id', $id);
		$this->db->delete('store_products');
	}

/*
************************
*********VIEW STORE PRODUCT
************************
*/

	public function getStoreProducts($id = FALSE)
	{

		$this->db->select('w.*,w.id as wid,w.user_id as wuid,p.*,p.id as pid,sp.*');
		//$this->db->select('p.*','w.*');
		$this->db->from('store_products as sp','wishlists as w');
		$this->db->join('products as p', 'sp.product_id = p.id','left');
		$this->db->join('wishlists as w', 'w.storeproduct_id = sp.sp_id AND w.user_id = '.$this->userID,'left');

		if($id){
			$this->db->where('sp.sp_id', $id);
			$query = $this->db->get();
			return $query->row();
		}else{
			$query = $this->db->get();
			$data = $query->result();
			foreach($data as $value){
				$resultSet[$value->sp_id] = $value;
			}
			//print_r($resultSet);die;
			return $resultSet;
		}
	}

/*
************************
*********GET ALL STORE PRODUCT OF SPECIFIC PRODUCT
************************
*/

	public function getStoreProductsByPid($id = FALSE)
	{
		$this->db->select('w.*,w.id as wid,w.user_id as wuid,p.*,p.id as pid,sp.*');
		//$this->db->select('p.*','w.*');
		$this->db->from('store_products as sp','wishlists as w');
		$this->db->join('products as p', 'sp.product_id = p.id','left');
		$this->db->join('wishlists as w', 'w.storeproduct_id = sp.sp_id AND w.user_id = '.$this->userID,'left');

		$this->db->where('p.id', $id);
		$query = $this->db->get();
		$data = $query->result();
		foreach($data as $value){
			$resultSet['storeProductDt'][$value->sp_id] = $value;
		}


		$this->db->from('products as p');
		$this->db->where('p.id', $id);
		$productData = $this->db->get();

		$resultSet['productDT'] = $productData->row();

		return $resultSet;

	}






/*
*************************************
*********WISHLIST********************
*************************************
*/

/*
************************
*********ADD WISHLIST
************************
*/

	public function addtowishlistdata($data)
	{
			$this->load->helper('url');
			$savewishlistdata = $this->db->insert('wishlists', $data);
			//print_r($savewishlistdata);die;
			if($savewishlistdata){
				return 1;
				//echo json_encode(array("status" => 'Product is added successfully'));
				/*$this->db->from('wishlist');
				$query = $this->db->get();
				return $query->result();*/
			}
			else{
				return 0;
				//echo json_encode(array("status" => 'Product not added to wishlist'));
			}

	}
/*
************************
*********DELETE WISHLIST
************************
*/

	public function removefromwishlistdata($id){

		$this->db->where('id', $id);
		$result = $this->db->delete('wishlists');
		return $result;

	}

/*
************************
*********VIEW ALL WISHLIST
************************
*/
	public function getwishlistdata()
	{

		$this->db->select('w.*,w.id as wid,p.*,p.id as pid,sp.*');
		//$this->db->select('p.*','w.*');
		$this->db->from('store_products as sp','wishlists as w');
		$this->db->join('products as p', 'sp.product_id = p.id','left');
		$this->db->join('wishlists as w', 'w.storeproduct_id = sp.sp_id AND w.user_id = '.$this->userID,'inner');

		$query=$this->db->get();
		//print_r($query->result());die;
		return $query->result();

	}

/*
************************
*********VIEW WISHLIST
************************
*/

	public function get_wishlist_by_id($id)
	{
		$this->db->from('wishlists');
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row();
	}/*
************************
*********VIEW WISHLIST BY PRODUCT ID
************************
*/

	public function get_wishlist_by_pid($id,$userID)
	{
		$this->db->from('wishlists');
		$this->db->where('storeproduct_id',$id);
		$this->db->where('user_id',$userID);
		$query = $this->db->get();
		return $query->row();
	}


/*
*************************************
*********GET ATTRIBUTES *************
*************************************
*/

	public function get_categories()
	{
		$this->db->from('categories');
		$this->db->where('active', 1);
		$query=$this->db->get();
		$data = $query->result();
		foreach($data as $value){
			$resultSet[$value->cid] = $value;
		}
		//print_r($resultSet);die;
		return $resultSet;
	}



	public function get_locations()
	{
		$this->db->from('locations');
		$this->db->where('active', 1);
		$query=$this->db->get();
		$data = $query->result();
		foreach($data as $value){
			$resultSet[$value->lid] = $value;
		}
		//print_r($resultSet);die;
		return $resultSet;
	}

	public function get_stores()
	{
		$this->db->from('stores');
		$this->db->where('active', 1);
		$query=$this->db->get();
		$data = $query->result();
		foreach($data as $value){
			$resultSet[$value->sid] = $value;
		}
		//print_r($resultSet);die;
		return $resultSet;
	}


/*
*************************************
*********SEARCH FUNCTIONS************
*************************************
*/
	public function searchData($sData)
	{	$resultSet = [];$stags ='';
		$this->db->select('w.*,w.id as wid,w.user_id as wuid,p.*,p.id as pid,c.*,sp.*');
	//	$this->db->distinct('sp.product_id');
		$this->db->from('products as p');
		$this->db->join('store_products as sp', 'sp.product_id = p.id','INNER');
		$this->db->join('wishlists as w', 'w.storeproduct_id = sp.sp_id AND w.user_id ='.$this->userID,'left');
		$this->db->join('locations as l', 'l.lid = sp.loc_id','left');
		$this->db->join('categories as c', 'c.cid = p.cat_id','left');
		$this->db->join('stores as s', 's.sid = sp.store_id','left');

		$this->db->order_by('sp.pbase_price', 'DESC');
	  $this->db->group_by('sp.product_id');


		if($sData['sloc'] !=''){
			$this->db->where("(l.loc_name = '".$sData['sloc']."' or l.loc_pincode = '".$sData['sloc']."')");
		}

		if($sData['scat'] !=''){
			$this->db->where("(c.cat_name = '".$sData['scat']."')");//'".$sData['cat']."')");
		}

		if($sData['sstore'] !=''){
			$this->db->where("(s.store_name = '".$sData['sstore']."')");
		}


		if($sData['stag'] !=''){
			$stags = '(';
			$ptags = explode(",",$sData['stag']);//print_r($ptags);die;
			foreach($ptags as $pkey => $ptag){

				if($pkey != 0){	$stags .= ' OR ';}
				$stags .= "p.name LIKE '%".$ptag."%'";
				$stags .= " OR c.cat_name LIKE '%".$ptag."%'";
				$stags .= " OR p.tags LIKE '%".$ptag."%'";

			}
			$stags .= ')';

			$this->db->where($stags);
		}

		// AND l.loc_name = '".$searchData['loc']."'
		/*foreach($ptags as $ptag){
				$this->db->where("p.tags LIKE '%".$ptag."%'");
		}*/
		//$this->db->where("(p.tags LIKE '%".$sData['tag']."%' OR p.tags LIKE '%snack%')");


		$query = $this->db->get();
		$data = $query->result();
		foreach($data as $value){
			$resultSet[$value->sp_id] = $value;
		}
		//echo $this->db->last_query();

		//echo '<pre>';print_r($data);
		return $resultSet;
	}

	public function get_cheaper_product($pData,$searchItems)
	{
		$resultSet = [];


		$this->db->select('w.*,w.id as wid,w.user_id as wuid,p.*,p.id as pid,c.*,sp.*');
		//$this->db->select('p.*','w.*');
		$this->db->from('store_products as sp');
		//$this->db->join('store_products as sp_dt', 'sp_dt.pbase_price <= sp.pbase_price','inner');
		$this->db->join('products as p', 'sp.product_id = p.id','left');
		$this->db->join('wishlists as w', 'w.storeproduct_id = sp.sp_id AND w.user_id ='.$this->userID,'left');
		$this->db->join('categories as c', 'c.cid = p.cat_id','left');


		//$this->db->where("sp.sp_id != ".$pData->sp_id);
		$this->db->where("sp.sp_id IN(SELECT sp_id FROM store_products WHERE pbase_price <= ".$pData->pbase_price." AND sp_id != ".$pData->sp_id.")");
		$this->db->where("p.cat_id",$pData->cat_id);
		//$this->db->where("p.tags LIKE '%".$pData->tags."%'");
		//$sData['tag'] = $pData->tags;

		if($searchItems['stag'] !=''){
			$stags = '(';
			$ptags = explode(",",$searchItems['stag']);//print_r($ptags);die;
			foreach($ptags as $pkey => $ptag){

				if($pkey != 0){	$stags .= ' OR ';}
				$stags .= "p.name LIKE '%".$ptag."%'";
				$stags .= " OR c.cat_name LIKE '%".$ptag."%'";
				$stags .= " OR p.tags LIKE '%".$ptag."%'";


			}
			$stags .= ')';

			$this->db->where($stags);
		}

		//$this->db->group_by('p.loc_id');
		$this->db->order_by('sp.pbase_price', 'asc');

		$query = $this->db->get();

		$data = $query->result();
		//echo $this->db->last_query();

		//echo '<pre>';print_r($data);die;
		foreach($data as $value){
		$resultSet[$value->loc_id][$value->store_id][] = $value;
		//$resultSet[$value->loc_id][] = $value;
		}
		//print_r($resultSet);die;
		return $resultSet;

	}

	public function getProductsId($value){
		$this->db->select('name','id');
        $this->db->from('products');
		$this->db->where('name LIKE "%'.$value.'%"');
		$query = $this->db->get();
        return $query->result();
	}

}
