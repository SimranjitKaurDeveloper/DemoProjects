
    <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">

	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>

				<div class="col-sm-9 padding-right">
					<?php if($message != ''){ echo '<span class="success">'.$message.'</span>';
					}?>
					<h2>Add a Product item</h2>
					<?php echo validation_errors(); ?>
					<?php echo form_open_multipart('products/create') ?>

					<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
						<!--<tr>
							<td>Search For Existing Product</td>
							<td>
							<input type="input" name="productId" class="form-control" onkeyup="showSuggestions(this.value);" />

							<ul class="dropdown-menu txtprod" style="margin-left:15px;margin-right:0px;" role="menu" aria-labelledby="dropdownMenu"  id="DropdownProd"></ul>
							</td>
						</tr>-->





						<tr><td>Product Name</td><td><input type="input" name="productname" /></td></tr>
            <tr><td>Product Description</td><td><textarea row="3" name="productdesc" ></textarea></td></tr>
						<tr><td>Product Price</td><td><input type="input" name="productprice" /></td></tr>
            <tr><td>Image Upload</td><td><input type="file" name="itemImage" /></td></tr>
						<tr><td>Product Quantity</td><td><input type="input" name="productquantity" /></td></tr>
						<tr><td>Product Unit</td><td>

							<select name="productunit" />
								<option value="">Please select product unit</option>
                <?php foreach($this->productUnitOptions as $pUnitKey => $pUnitVal){ ?>
								          <option value="<?php echo $pUnitKey; ?>"><?php echo $pUnitVal; ?></option>
                <?php } ?>
							</select>
						</td></tr>
						<tr><td>Product Category</td><td>
							<select name="productcategory" />
								<option value="">Please select product category</option>
							  <?php foreach($categories as $cat => $value){ ?>

								<option value="<?php echo $value->cid;?>"><?php echo $value->cat_name; ?></option>
							 <?php } ?>
							</select>
						</td></tr>
						<tr><td>Product Location</td><td>
							<select name="productlocation" />
								<option value="">Please select location</option>
							  <?php foreach($locations as $loc => $value){ ?>

								<option value="<?php echo $value->lid;?>"><?php echo $value->loc_name; ?></option>
							 <?php } ?>
							</select>
						</td></tr>
						<tr><td>Product Store</td><td>
							<select name="productstore" />
								<option value="">Please select store</option>
							  <?php foreach($stores as $store => $value){ ?>

								<option value="<?php echo $value->sid;?>"><?php echo $value->store_name; ?></option>
							 <?php } ?>
							</select>
						</td></tr>
						<!--<tr><td>Product Tags<p><i>(By which product will be searched like apple, juice)</i></p></td><td><input type="input" name="producttag" /></td></tr>-->


						<tr><td></td><td> <input type="submit" name="submit" class="btn btn-primary" value="Add Product" /></td></tr>

					</table>
				</div>
			</div>
		</div>
	</section>
	 <script src="<?php echo base_url('js/jquery.autocomplete.min.js')?>"></script>

  <script type="text/javascript">
    $(document).ready(function () {

      $('ul.txtprod').on('click', 'li a', function () {
        $('#productId').val($(this).text());
      });
    });
  </script>
    <script type="text/javascript">
  /*$(document).ready(function() {
    $(function(){
        $( "#productId" ).autocomplete({
        source: function(request, response) {
            $.ajax({
            url: "<?php //echo site_url('products/showSuggestions/white'); ?>",
            data: { term: $("#productId").val()},
            dataType: "json",
            type: "POST",
            success: function(data){
               var resp = $.map(data,function(obj){
                    return obj.tag;
               });

               response(resp);
            }
        });
    },
    minLength: 2
})
    })
});*/




	/*	function showSuggestions(term){
			//term = $('#productId').val();
			if(term !=''){
				pathURL = "<?php //echo site_url('products/ajax_showSuggestions/"+term+"'); ?>";
				$.ajax({
				  url :pathURL,
				  type: "GET",
				  dataType: "JSON",
				  success: function(data)
				  { console.log(data);showdt = {};
				  $.each(data, function (key,value) {
					  showdt[key] = {'value': value['id']};
					  showdt[key]['data'] = value['name'];
				  })
var myJsonString = JSON.stringify(showdt);
					  $('#productId').autocomplete({
    lookup: myJsonString,
    onSelect: function (suggestion) {
     // var thehtml = '<strong>Currency Name:</strong> ' + suggestion.value + ' <br> <strong>Symbol:</strong> ' + suggestion.data;
     // $('#outputcontent').html(thehtml);
    }
  });*/

					  /*if (data.length > 0) {
							$('#DropdownProd').empty();
							$('#productId').attr("data-toggle", "dropdown");
							$('#DropdownProd').dropdown('toggle');
						}
						else if (data.length == 0) {
							$('#productId').attr("data-toggle", "");
						}
						$.each(data, function (key,value) {
							if (data.length >= 0)
								$('#DropdownProd').append('<li role="displayCountries" ><a role="menuitem dropdownCountryli" class="dropdownlivalue">' + value['name'] + '</a></li>');
						});*/
				 /* },
				  error: function (jqXHR, textStatus, errorThrown)
				  {
					console.warn(jqXHR.responseText);
					alert(errorThrown);
					  alert('Error get data from ajax');
				  }
			  });

				/*$.ajax({
					type: "POST",
					url: URL,
					data: {
						keyword: $("#productId").val()
					},
					dataType: "json",
					success: function (data) { alert('pp');
						/*if (data.length > 0) {
							$('#DropdownProd').empty();
							$('#productId').attr("data-toggle", "dropdown");
							$('#DropdownProd').dropdown('toggle');
						}
						else if (data.length == 0) {
							$('#productId').attr("data-toggle", "");
						}
						$.each(data, function (key,value) {
							if (data.length >= 0)
								$('#DropdownProd').append('<li role="displayCountries" ><a role="menuitem dropdownCountryli" class="dropdownlivalue">' + value['name'] + '</a></li>');
						});*/
					/*}
				});*/
		<?php /*	}
  }
	</script>
	<style>

.autocomplete-suggestions { border: 1px solid #999; background: #fff; cursor: default; overflow: auto; }
.autocomplete-suggestion { padding: 10px 5px; font-size: 1.2em; white-space: nowrap; overflow: hidden; }
.autocomplete-selected { background: #f0f0f0; }
.autocomplete-suggestions strong { font-weight: normal; color: #3399ff; }
	</style>
  */ ?>
