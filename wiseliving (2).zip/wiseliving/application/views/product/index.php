<?php //print_r($products);die;?>
<section id="advertisement">
		<div class="container">
			<img src="images/shop/advertisement.jpg" alt="" />
		</div>
	</section>

	<section>
		<div class="container" id="products">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Product List</h2>
						<?php foreach($products as $product){?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<p><a href="<?php echo base_url().'products/view/'.$product->sp_id;?>" >
											<img src="<?php echo base_url().'images/products/'.$product->image;?>" width="200px" height="200px" />
											</a></p>

											<h2><?php echo '$'.$product->price.' ('.$product->quantity.''.$product->unit.')';?></h2>
											<p><a href="<?php echo base_url().'products/view/'.$product->sp_id.'?'.$current_params;?>" >
											<?php echo substr($product->name,0,35).'...';?></a></p>
											<p><?php echo $stores[$product->store_id]->store_name.', '.$locations[$product->loc_id]->loc_name;?></p>
											<p><b><?php echo '$'.$product->pbase_price.' per '.$product->base_unit;?></b></p>
										</div>
										<!--
										<div class="product-overlay">
											<div class="overlay-content">
												<h2><?php echo $product->price;?></h2>
												<p><a href="<?php echo base_url().'/products/view/'.$product->pid;?>" ><?php echo $product->name;?></a></p>

											</div>
										</div>-->
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li>
										<?php
											//print_r($product);echo $userID;
										 if(isset($product->wid) && $product->wid != '' && $userID == $product->wuid ){ ?>
											<a href="#" onclick="removeFromWishlist(<?php echo $product->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>

										<?php }else{ ?>
											<a href="#" onclick="addToWishlist(<?php echo $product->sp_id;?>)"><i class="fa fa-plus-square"></i>Add to wishlist</a>
										<?php } ?>
										</li>
										<!--<li><a href="<?php echo base_url('/products/view/'.$product->sp_id); ?>"><i class="fa fa-plus-square"></i>Add to compare</a></li>-->

									</ul>
								</div>
							</div>
						</div>
						<?php } ?>

						<!--<ul class="pagination">
							<li class="active"><a href="">1</a></li>
							<li><a href="">2</a></li>
							<li><a href="">3</a></li>
							<li><a href="">&raquo;</a></li>
						</ul>-->
					</div><!--features_items-->

				</div>
			</div>
		</div>
	</section>

	<script type="text/javascript">
		function addToWishlist(id)
        {
          //Ajax Load data from ajax
					uid = "";
					uid = "<?php echo $userID;?>";
				if(uid == "0"){
						window.location = "<?php echo site_url('auth/login')?>";
				}else{


          $.ajax({
            url : "<?php echo site_url('products/addToWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
							if(data.status){
									if(data.status == 'success'){	alert("Product added in the wishlist.");
									}else if(data.status == 'failure'){ alert("Product already in the wishlist.");
									}else{ alert('Product not added in wishlist');

									}

							}else{
								alert('Product not added in wishlist, error occurs');

							}
								location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
							console.warn(jqXHR.responseText);
							console.warn(jqXHR);
							alert(errorThrown);
						}
         });
}

        }
		function removeFromWishlist(id)
        {
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('products/removeFromWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
									if(data.status == 'success'){	alert("Product removed from wishlist.");
									}else if(data.status == 'failure'){	alert("Product not removed from wishlist.");

									}else{ alert('error');
									}
									location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
								console.warn(jqXHR.responseText);
								console.warn(jqXHR);
								alert(errorThrown);
							}
         });


        }



  </script>
