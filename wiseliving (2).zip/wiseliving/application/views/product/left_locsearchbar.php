<?php $selectedLoc = array_keys($cheaperProd); ?>
<div class="left-searchbar">
	<?php
	$storeList = [];
	$sloc = $search['sloc'];
	$sstore = $search['sstore'];

	?>

	<h2>Locations</h2>
	<?php foreach($selectedLoc as $locId){
		//print('<pre>');	print_r($cheaperProd[$locId]);
		//$getStoreKey = array_keys($cheaperProd[$locId]);
		$storeList = array_unique(array_merge($storeList, array_keys($cheaperProd[$locId])));
		//print_r(array_keys($cheaperProd[$locId]));print_r($storeList);
		?>
	<div class="checkbox">
		<?php
		if($sloc!='' && ($locations[$locId]->loc_name == $sloc || $locations[$locId]->loc_pincode == $sloc) ){
			$check = 'checked="checked"';
		}elseif($sloc == ''){	$check = 'checked="checked"';
		}else{	$check = '';
		}
		?>

		<label><input type="checkbox" onchange="searchloc_items();" name="plocation" <?php echo $check;?> value="<?php echo $locId; ?>" ><?php echo $locations[$locId]->loc_name?><?php echo '('.count($cheaperProd[$locId]).')'; ?></label>
	</div>
	<?php } ?>


	<h2>Stores</h2>

	<?php //print_r($storeList);$storeList = array_unique($storeList);
	foreach($storeList as $store){ ?>
	<div class="checkbox">
		<?php
		if($sstore!='' && $stores[$store]->store_name == $sstore){
			$check = 'checked="checked"';
		}elseif($sstore == ''){	$check = 'checked="checked"';
		}else{	$check = '';
		}
		?>

		<label><input type="checkbox" rel="<?php echo $stores[$store]->store_name; ?>" onchange="searchstore_items();" <?php echo $check;?> name="sstore" value="<?php echo $store; ?>"><?php echo $stores[$store]->store_name; ?></label>
	</div>
	<?php } ?>

</div>
