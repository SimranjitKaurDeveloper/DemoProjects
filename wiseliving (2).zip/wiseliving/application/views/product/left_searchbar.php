
<div class="left-searchbar">
	<h2>Category</h2>
	<?php  

	$scat = $search['scat'];
	$sstore = $search['sstore'];
	?>
	<?php foreach($categories as $cat => $value){ ?>
	<div class="checkbox">
	  <label><input type="radio" rel="<?php echo $value->cat_name; ?>" onchange="searchParam(this);" name="scat" value="<?php echo $value->cid; ?>" <?php if($scat!='' && $value->cat_name == $scat ){echo 'checked="checked"';}?>><?php echo $value->cat_name; ?></label>
	</div>
	<?php } ?>

	<h2>Stores</h2>

	<?php foreach($stores as $store => $value){ ?>
	<div class="checkbox">
	  <label><input type="radio" rel="<?php echo $value->store_name; ?>" onclick='searchParam(this);' name="sstore" value="<?php echo $value->sid; ?>" <?php if($sstore!='' && $value->store_name == $sstore ){echo 'checked="checked"';}?>>
	  <?php echo $value->store_name; ?></label>
	</div>
	<?php } ?>

</div>

<script type="text/javascript">

	
	function searchParam(cb) { 
		name = cb.name; 
		//text = $('input[name="'+name+'"]:checked').parent().text();
		text = $('input[name="'+name+'"]:checked').attr('rel');//alert(text);
		insertParam(name,text);
		 
	}

</script>
