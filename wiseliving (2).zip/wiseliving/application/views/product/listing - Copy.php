
	<section>
		<div class="container">
			<div class="row">
				<?php /*<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>*/ ?>

				<div class="col-sm-12 padding-right">
					<div class="product-details"><!--product-details-->
						<p><a href="<?php echo base_url().'products/create'; ?>" >Create a new Product</a></p>
						<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead><h1>Product Information</h1>
									<tr>
										<th>Product ID</th>
										<th>Product Name</th>
										<th>Product Price</th>
										<th>Product Quantity</th>
										<th>Product Store</th>
										<th>Product Location</th>
										<th style="width:125px;">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($products as $product){?>
									 <tr>
										<td><?php echo $product->id;?></td>
										<td><a href="<?php echo base_url().'products/view/'.$product->pid;?>" ><?php echo $product->name;?></a></td>
										<td><?php echo $product->price;?></td>
										<td><?php echo $product->quantity;?> <?php echo $product->units;?></td>
										<td><?php if($product->loc_id){ echo $locations[$product->loc_id]->loc_name;}?></td>
										<td><?php if($product->store_id){ echo $stores[$product->store_id]->store_name;}?></td>
										<td>
											<button class="btn btn-warning" onclick="edit_product(<?php echo $product->pid;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
											<button class="btn btn-danger" onclick="delete_product(<?php echo $product->pid;?>)"><i class="glyphicon glyphicon-remove"></i></button>

											<!--<button class="btn btn-warning" onclick="addToWishlist(<?php echo $product->id;?>)"><i class="fa fa-plus-square"></i> Add to wishlist</button>-->

										</td>
									  </tr>
									 <?php }?>
								</tbody>
								<tfoot>

								</tfoot>
						</table>
				
					</div><!--/product-details-->


					<!-- Bootstrap modal -->
					  <div class="modal fade" id="modal_form" role="dialog">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h3 class="modal-title">Product Details</h3>
						  </div>
						  <div class="modal-body form">
								<form action="#" id="form" class="form-horizontal">
									<input type="hidden" value="" name="productid"/>
										  <div class="form-body">
											
											<div class="form-group">
											  <label class="control-label col-md-3">Product Name</label>
											  <div class="col-md-9">
												<input name="productname" placeholder="Product name" class="form-control" type="text">
											  </div>
											</div>
											
											<div class="form-group">
											  <label class="control-label col-md-3">Product Description</label>
											  <div class="col-md-9">
												<input name="productdesc" placeholder="Product Description" class="form-control" type="text">

											  </div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Price</label>
												<div class="col-md-9">
													<input name="productprice" placeholder="Product Price" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Quantity</label>
												<div class="col-md-9">
													<input name="productqty" placeholder="Product Quantity" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Unit</label>
												<div class="col-md-9">
													<input name="productunit" placeholder="Product Unit" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Categories</label>
											  <div class="col-md-9">
												<select name="productcategory" required/>
													
												  <?php foreach($categories as $cat => $value){ ?>

													<option value="<?php echo $value->cid;?>"><?php echo $value->cat_name; ?></option>
												 <?php } ?> 
												</select>
											  </div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Locations</label>
											  <div class="col-md-9">
												<select name="productlocation" />
													
												  <?php foreach($locations as $loc => $value){ ?>

													<option value="<?php echo $value->lid;?>"><?php echo $value->loc_name; ?></option>
												 <?php } ?> 
												</select>
											  </div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Store</label>
											  <div class="col-md-9">
												<select name="productstore" />
													
												  <?php foreach($stores as $store => $value){ ?>

													<option value="<?php echo $value->sid;?>"><?php echo $value->store_name; ?></option>
												 <?php } ?> 
												</select>
											  </div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Tags</label>
											  <div class="col-md-9">
												<input type="input" name="producttag" placeholder=""/>
											  </div>
											</div>
								</div>
							</form>
							  </div>
							  <div class="modal-footer">
								<button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
							  </div>
							</div><!-- /.modal-content -->
						  </div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
					  <!-- End Bootstrap modal -->


					<?php /*
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">recommended items</h2>

						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/12.jpg" alt="" />
													<h2>$8.50</h2>
													<p>Sara Lee Chocolate Ice Cream 1L</p>

												</div>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/18.jpg" alt="" />
													<h2>$13.30</h2>
													<p>Cold Power Powder 2kg</p>

												</div>
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/19.jpg" alt="" />
													<h2>$5.75</h2>
													<p>Morning Fresh Dishwashing Liquid</p>

												</div>

											</div>
										</div>
									</div>
								</div>
								<div class="item">
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/5.jpg" alt="" />
													<h2>$6.50</h2>
													<p>Mini Choc Chip Hot Cross Buns 9pk</p>

												</div>

											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/17.jpg" alt="" />
													<h2>$6</h2>
													<p>Dove Beauty Soap 4x100g</p>

												</div>

											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/products/6.jpg" alt="" />
													<h2>$3.50</h2>
													<p>Wonder White Bread Vitamins & Minerals Sandwich 700g</p>

												</div>

											</div>
										</div>
									</div>
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>
						</div>
					</div><!--/recommended_items-->
					*/ ?>

				</div>
			</div>
		</div>
	</section>
	  <script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>

  <script type="text/javascript">

  $(document).ready( function () {
        $('#table_id').DataTable();
    } );



  	function edit_product(id)
      {
        save_method = 'update';
       // $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('products/ajax_edit/')?>/" + id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {

              $('[name="productid"]').val(data.id);
              $('[name="productname"]').val(data.name);
              $('[name="productdesc"]').val(data.description);
              $('[name="productprice"]').val(data.price);
        	  $('[name="productqty"]').val(data.quantity);
        	  $('[name="productunit"]').val(data.units);
			  $('[name="productcategory"]').val(data.cat_id);
        	  $('[name="productlocation"]').val(data.loc_id);
        	  $('[name="productstore"]').val(data.store_id);
			  $('[name="producttag"]').val(data.tags);
        			
			  //$('#table_id').css("display","none");
              $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
              $('.modal-title').text('Edit Product'); // Set title to Bootstrap modal title

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
  			console.warn(jqXHR.responseText);
  			alert(errorThrown);
              alert('Error get data from ajax');
          }
      });


      }
  	function save()
      {
        var url;
        if(save_method == 'add')
        {
            url = "<?php echo site_url('products/product_add')?>";
        }
        else
        {
          url = "<?php echo site_url('products/product_update')?>";
        }

         // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 //if success close modal and reload ajax table
                 $('#modal_form').modal('hide');
  				 $('#table_id').css("display","block");
                 location.reload();// for reload a page
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
  				console.warn(jqXHR.responseText);
                  alert('Error adding / update data');
              }
          });
      }

  	function delete_product(id)
      {
        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
            $.ajax({
              url : "<?php echo site_url('products/product_delete')?>/"+id,
              type: "POST",
              dataType: "JSON",
              success: function(data)
              {
                 location.reload();
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
  				console.warn(jqXHR.responseText);
                  alert('Error deleting data');
              }
          });

        }
      }


      function addToWishlist(id)
        {
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('products/addToWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
				if(data.status == false)
				{
					alert("Product already in the wishlist.");
				}
				else
				{	alert("Product added in the wishlist.");
					//window.location.href = "<?php echo site_url('products/wishlist'); ?>";
				}
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				console.warn(jqXHR.responseText);
				console.warn(jqXHR);
				alert(errorThrown);
			}
        });


        }
  </script>
