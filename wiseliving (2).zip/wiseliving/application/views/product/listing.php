<?php //echo '<pre>';print_r($products);die;?>
	<section>
		<div class="container">
			<div class="row">
				<?php /*<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>*/ ?>

				<div class="col-sm-12 padding-right">
					<div class="product-details"><!--product-details-->
						<p><a href="<?php echo base_url().'products/create'; ?>" >Create a new Product</a></p>
						<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead><h1>Product Information</h1>
									<tr>
										<th>Product</th>
										<th>Product Name</th>
										<th style="width:300px;">Product Description</th>
										<th>Product Category</th>
										<th>Product Base Unit</th>
										<!--<th>Product Tags</th>-->
										<th style="width:150px;">Action</th>

									</tr>
								</thead>
								<tbody>
									<?php foreach($products as $product){?>
									 <tr>
										<td>	<img src="<?php echo base_url().'images/products/'.$product->image;?>" width="50px" height="50px" alt="" /></td>
										<td><a href="<?php echo base_url().'products/view/'.$product->pid;?>" ><?php echo $product->name;?></a></td>
										<td><?php	$para = explode("\n",wordwrap($product->description, 150, "\n", true));echo $para[0];?></td>
										<td><?php if($product->cat_id){ echo $categories[$product->cat_id]->cat_name;}?></td>
										<td><?php echo $product->base_qty.' '.$product->base_unit;?></td>
										<!--<td><?php //echo $product->tags;?></td>-->
										<td>
											<a href="<?php echo base_url().'products/store_products/'.$product->pid;?>">View Store Products</a>
											<button class="btn btn-warning" onclick="edit_product(<?php echo $product->pid;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
											<button class="btn btn-danger" onclick="delete_product(<?php echo $product->pid;?>)"><i class="glyphicon glyphicon-remove"></i></button>

											<!--<button class="btn btn-warning" onclick="addToWishlist(<?php echo $product->id;?>)"><i class="fa fa-plus-square"></i> Add to wishlist</button>-->

										</td>
									  </tr>
									 <?php }?>
								</tbody>
								<tfoot>

								</tfoot>
						</table>

					</div><!--/product-details-->


					<!-- Bootstrap modal -->
					  <div class="modal fade" id="modal_form" role="dialog">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h3 class="modal-title">Product Details</h3>
						  </div>
						  <div class="modal-body form">
								<form action="#" id="form" class="form-horizontal" enctype="multipart/form-data">
									<input type="hidden" value="" name="productid"/>
										  <div class="form-body">

											<div class="form-group">
											  <label class="control-label col-md-3">Product Name</label>
											  <div class="col-md-9">
												<input name="productname"  placeholder="Product name" class="form-control" type="text">
											  </div>
											</div>
											<div class="form-group">
											  <label class="control-label col-md-3">Product Description</label>
											  <div class="col-md-9">
												<textarea name="productdesc" row="3" placeholder="Product Description" class="form-control">
												</textarea>
											  </div>
											</div>

											<!--<div class="form-group">
											  <label class="control-label col-md-3">Product Description</label>
											  <div class="col-md-9">
												<input name="productdesc" placeholder="Product Description" class="form-control" type="text">

											  </div>
											</div>-->

											<div class="form-group">
												<label class="control-label col-md-3">Product Quantity</label>
												<div class="col-md-9">
													<input name="productquantity" placeholder="Product Quantity" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Unit</label>
												<div class="col-md-9">
													<!--<input name="productunit" placeholder="Product Unit" class="form-control" type="text">-->
													<select name="productunit" />
														<option value="">Please select product unit</option>
														<?php foreach($this->productUnitOptions as $pUnitKey => $pUnitVal){ ?>
														          <option value="<?php echo $pUnitKey; ?>"><?php echo $pUnitVal; ?></option>
						                <?php } ?>
													</select>

												</div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Categories</label>
											  <div class="col-md-9">
												<select name="productcategory" required />

												  <?php foreach($categories as $cat => $value){ ?>

													<option value="<?php echo $value->cid;?>"><?php echo $value->cat_name; ?></option>
												 <?php } ?>
												</select>
											  </div>
											</div>

											<!--<div class="form-group">
											  <label class="control-label col-md-3">Product Tags</label>
											  <div class="col-md-9">
												<input type="input" name="producttag" placeholder=""/>
											  </div>
											</div>-->
								</div>
							</form>
							  </div>
							  <div class="modal-footer">
								<button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
							  </div>
							</div><!-- /.modal-content -->
						  </div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
					  <!-- End Bootstrap modal -->

				</div>
			</div>
		</div>
	</section>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>

  <script type="text/javascript">

  $(document).ready( function () {
        $('#table_id').DataTable({stateSave: true});
    } );



  	function edit_product(id)
      {
        save_method = 'update';
       // $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('products/ajax_edit/product')?>/" + id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {

            $('[name="productid"]').val(data.pid);
            $('[name="productname"]').val(data.name);
            $('[name="productdesc"]').val(data.description);
        	  $('[name="productquantity"]').val(data.base_qty);
        	  $('[name="productunit"]').val(data.base_unit);
			  		$('[name="productcategory"]').val(data.cat_id);
			  	//	$('[name="producttag"]').val(data.tags);

			  //$('#table_id').css("display","none");
              $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
              $('.modal-title').text('Edit Product'); // Set title to Bootstrap modal title

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
  			console.warn(jqXHR.responseText);
  			alert(errorThrown);
              alert('Error get data from ajax');
          }
      });


      }
  	function save()
      {
        var url;
        url = "<?php echo site_url('products/product_update')?>";


         // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 //if success close modal and reload ajax table
				 if(data['status']){
					 $('#modal_form').modal('hide');
					 $('#table_id').css("display","block");
					 alert('Updated successfully');
					 location.reload();// for reload a page
				 }else{
					 alert(data['error']);
					 alert('Product Not Updated, Please try again');
				 }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
  				console.warn(jqXHR.responseText);
                  alert('Error adding / update data');
              }
          });
      }

  	function delete_product(id)
      {
        if(confirm('Are you sure delete the product, as all store data related to product will get deleted?'))
        {
			pathUrl = "<?php echo site_url('products/product_delete')?>/"+id;

			if(pathUrl !=''){
				// ajax delete data from database
				$.ajax({
				  url : pathUrl,
				  type: "POST",
				  dataType: "JSON",
				  success: function(data)
				  {
					 location.reload();
				  },
				  error: function (jqXHR, textStatus, errorThrown)
				  {
					console.warn(jqXHR.responseText);
					  alert('Error deleting data');
				  }
				});
			}

        }
      }


      function addToWishlist(id)
        {
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('products/addToWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
				if(data.status == false)
				{
					alert("Product already in the wishlist.");
				}
				else
				{	alert("Product added in the wishlist.");
					//window.location.href = "<?php echo site_url('products/wishlist'); ?>";
				}
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				console.warn(jqXHR.responseText);
				console.warn(jqXHR);
				alert(errorThrown);
			}
        });


        }
  </script>
