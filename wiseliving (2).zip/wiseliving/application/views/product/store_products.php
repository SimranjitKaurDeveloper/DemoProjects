<?php //echo '<pre>';print_r($products);die;?>
	<section>
		<div class="container">
			<div class="row">
				<?php /*<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>*/ ?>

				<div class="col-sm-12 padding-right">
					<div class="product-details"><!--product-details-->
						<p><a href="#" onclick="add_storeproduct()" >Create a new Store Product</a></p>

						<div class="product-details"><!--product-details-->
							<div class="col-sm-3">
								<div class="view-product1">
									<img src="<?php echo base_url().'images/products/'.$products['productDT']->image;?>" width="200px" height="200px" alt="" />

								</div>
							</div>
							<div class="col-sm-9">
								<div class="product-information"><!--/product-information-->
									<!--<img src="images/products/18.jpg" class="newarrival" alt="" />-->
									<h2><?php echo $products['productDT']->name; ?></h2>
									<div class="col-sm-9">
										<p><b>Categories:</br></b><?php echo $categories[$products['productDT']->cat_id]->cat_name; ?></p>
										<p><b>Tags:</br></b><?php echo $products['productDT']->tags; ?></p>
										<p><b>Description:</br></b><?php echo $products['productDT']->description; ?></p>
									</div>

									<!--<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>-->
								</div><!--/product-information-->
							</div>
						</div><!--/product-details-->
				</div>
						<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead><h1>Product Information</h1>
									<tr>
										<th>Product Location</th>
										<th>Product Store</th>
										<th>Product Price</th>
										<th style="width:150px;">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($products['storeProductDt'] as $product){?>
									 <tr>
										<td><?php if($product->loc_id){ echo $locations[$product->loc_id]->loc_name;}?></td>
										<td><?php if($product->store_id){ echo $stores[$product->store_id]->store_name;}?></td>

										<td><?php echo '$'.$product->price.' ('.$product->quantity.' '.$product->unit.')';?></td>

										<td>
											<a href="<?php echo base_url().'products/view/'.$product->pid;?>" >VIEW PRODUCT</a>
											<button class="btn btn-warning" onclick="edit_product(<?php echo $product->sp_id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
											<button class="btn btn-danger" onclick="delete_product(<?php echo $product->sp_id;?>)"><i class="glyphicon glyphicon-remove"></i></button>

											<!--<button class="btn btn-warning" onclick="addToWishlist(<?php echo $product->id;?>)"><i class="fa fa-plus-square"></i> Add to wishlist</button>-->

										</td>
									  </tr>
									 <?php }?>
								</tbody>
								<tfoot>

								</tfoot>
						</table>

					</div><!--/product-details-->


					<!-- Bootstrap modal -->
					  <div class="modal fade" id="modal_form" role="dialog">
					  <div class="modal-dialog">
						<div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="location.reload()"><span aria-hidden="true">&times;</span></button>
							<h3 class="modal-title">Product Details</h3>
						  </div>
						  <div class="modal-body form">
								<form action="#" id="form" class="form-horizontal">
									<input type="hidden" value="<?php echo $product->id;?>" name="productid"/>
									<input type="hidden" value="" name="store_productid"/>
										  <div class="form-body">

											<div class="form-group">
											  <label class="control-label col-md-3">Product Name</label>
											  <div class="col-md-9">
												<input name="productname" value="<?php echo $product->name;?>" disabled="none" placeholder="Product Name" class="form-control" type="text">(X)
											  </div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Categories</label>
												<div class="col-md-9">
												<select name="productcategory" disabled="none"  required/>

													<?php foreach($categories as $cat => $value){ ?>

													<option value="<?php echo $value->cid;?>" <?php if($product->cat_id == $value->cid){ echo 'selected="selected"'; } ?>><?php echo $value->cat_name; ?></option>
												 <?php } ?>
												</select>(X)
												</div>
											</div>

										<!--	<div class="form-group">
											  <label class="control-label col-md-3">Product Description</label>
											  <div class="col-md-9">
												<input name="productdesc" placeholder="Product Description" class="form-control" type="text">
												</div>
											</div>-->

											<div class="form-group">
												<label class="control-label col-md-3">Product Price</label>
												<div class="col-md-9">
													<input name="productprice" placeholder="Product Price" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Quantity</label>
												<div class="col-md-9">
													<input name="productquantity" placeholder="Product Quantity" class="form-control" type="text">

												</div>
											</div>

											<div class="form-group">
												<label class="control-label col-md-3">Product Unit</label>
												<div class="col-md-9">
													<!--<input name="productunit" placeholder="Product Unit" class="form-control" type="text">-->

													<select name="productunit" />
														<option value="">Please select product unit</option>
														<?php foreach($this->productUnitOptions as $pUnitKey => $pUnitVal){
															if($pUnitKey == $product->base_unit || $this->productUnitRel[$product->base_unit] == $pUnitKey || array_search($product->base_unit, $this->productUnitRel) ==  $pUnitKey){
															?>
																<option value="<?php echo $pUnitKey; ?>"><?php echo $pUnitVal; ?></option>
															<?php } ?>
						                <?php } ?>
													</select>

												</div>
											</div>



											<div class="form-group">
											  <label class="control-label col-md-3">Product Locations</label>
											  <div class="col-md-9">
												<select name="productlocation" />
														<option value="">Please select location</option>
												  <?php foreach($locations as $loc => $value){ ?>

													<option value="<?php echo $value->lid;?>"><?php echo $value->loc_name; ?></option>
												 <?php } ?>
												</select>
											  </div>
											</div>

											<div class="form-group">
											  <label class="control-label col-md-3">Product Store</label>
											  <div class="col-md-9">
												<select name="productstore" />
														<option value="">Please select store</option>
												  <?php foreach($stores as $store => $value){ ?>

													<option value="<?php echo $value->sid;?>"><?php echo $value->store_name; ?></option>
												 <?php } ?>
												</select>
											  </div>
											</div>

											<!--<div class="form-group">
											  <label class="control-label col-md-3">Product Tags</label>
											  <div class="col-md-9">
												<input type="input" name="producttag" placeholder=""/>
											  </div>
											</div>-->
								</div>
							</form>
							  </div>
							  <div class="modal-footer">
								<button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal" onclick="location.reload()" >Cancel</button>
							  </div>
							</div><!-- /.modal-content -->
						  </div><!-- /.modal-dialog -->
						</div><!-- /.modal -->
					  <!-- End Bootstrap modal -->

				</div>
			</div>
		</div>
	</section>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>

  <script type="text/javascript">

  $(document).ready( function () {
        $('#table_id').DataTable({stateSave: true});
    } );

		function add_storeproduct(id)
			{
					$('#modal_form').modal('show'); // show bootstrap modal when complete loaded
					$('.modal-title').text('Add Store Product');
			}
  	function edit_product(id)
      {
        save_method = 'update';
       // $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('products/ajax_edit/storeProd')?>/" + id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {

              $('[name="productid"]').val(data.pid);
              $('[name="store_productid"]').val(data.sp_id);//store_productid
              $('[name="productname"]').val(data.name);
            	//  $('[name="productdesc"]').val(data.description);
              $('[name="productprice"]').val(data.price);
        	  	$('[name="productquantity"]').val(data.quantity);
	        	  $('[name="productunit"]').val(data.unit);
				  		$('[name="productcategory"]').val(data.cat_id);
	        	  $('[name="productlocation"]').val(data.loc_id);
	        	  $('[name="productstore"]').val(data.store_id);
				  	//	$('[name="producttag"]').val(data.tags);

			  			//$('#table_id').css("display","none");

              $('#modal_form').modal({backdrop: 'static', keyboard: false}); // show bootstrap modal when complete loaded
              $('.modal-title').text('Edit Product'); // Set title to Bootstrap modal title

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
  			console.warn(jqXHR.responseText);
  			alert(errorThrown);
              alert('Error get data from ajax');
          }
      });


      }
  	function save()
      {
        var url;
        url = "<?php echo site_url('products/storeproduct_update')?>";


         // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 //if success close modal and reload ajax table
				 if(data['status']){
					 $('#modal_form').modal('hide');
					 $('#table_id').css("display","block");
					 	alert(data['message']);
					 location.reload();// for reload a page
				 }else{
					 alert(data['error']);
					 alert('Product Not Updated, Please try again');
				 }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
  				console.warn(jqXHR.responseText);
                  alert('Error adding / update data');
              }
          });
      }

  	function delete_product(id)
      {
        if(confirm('Are you sure delete this data?'))
        {	pathUrl = "<?php echo site_url('products/storeproduct_delete')?>/"+id;

			if(pathUrl !=''){
				// ajax delete data from database
				$.ajax({
				  url : pathUrl,
				  type: "POST",
				  dataType: "JSON",
				  success: function(data)
				  {
					 location.reload();
				  },
				  error: function (jqXHR, textStatus, errorThrown)
				  {
					console.warn(jqXHR.responseText);
					  alert('Error deleting data');
				  }
				});
			}

        }
      }


      function addToWishlist(id)
        {
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('products/addToWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
				if(data.status == false)
				{
					alert("Product already in the wishlist.");
				}
				else
				{	alert("Product added in the wishlist.");
					//window.location.href = "<?php echo site_url('products/wishlist'); ?>";
				}
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
				console.warn(jqXHR.responseText);
				console.warn(jqXHR);
				alert(errorThrown);
			}
        });


        }
  </script>
