
    <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">

	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>
				
				<div class="col-sm-9 padding-right">

					<h2>Product Item Addition Successful</h2>
					<tr>
					</tr>
				
         
        </tr>
     
		  </table>
					

				</div>
			</div>
		</div>
	</section>
	
	