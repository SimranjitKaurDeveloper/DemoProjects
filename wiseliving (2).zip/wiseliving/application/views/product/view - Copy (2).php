

	<section>
		<div class="container" id="productDetail">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-3">
							<div class="view-product1">
								<img src="<?php echo base_url().'images/products/'.$product->image;?>" width="200px" height="200px" alt="" />

							</div>
						</div>
						<div class="col-sm-9">
							<div class="product-information"><!--/product-information-->
								<!--<img src="images/products/18.jpg" class="newarrival" alt="" />-->
								<span>
										<span>$<?php echo $product->price; ?> (<?php echo $product->quantity; ?> <?php echo $product->unit; ?>)</span>
								</span>
								<h2><?php echo $product->name; ?></h2>
								<span class="baseprice" ><b><?php echo '$'.$product->pbase_price.' per '.$product->base_unit;?></b></span>
								<p><b>Category: </b><?php echo $categories[$product->cat_id]->cat_name; ?></p>
								<p><b>Store: </b><?php echo $stores[$product->store_id]->store_name; ?></p>
								<p><b>Location: </b><?php echo $locations[$product->loc_id]->loc_name; ?></p>


								<!--<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>-->
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->


					<?php
					$cheaperProd = array_filter($cheaperProd);

					if(!empty($cheaperProd)){ ?>
					<div class="compared_products">
						<span>OTHER CHEAPEST PRODUCTS HAVING LESS PRICE THAN SELECTED PRODUCT</span>
					<?php
					foreach($cheaperProd as $locId => $storeProd){ ?>

					<div class="recommended_items col-sm-12" id="rec_loc_items_<?php echo $locId; ?>"><!--recommended_items-->
						<h2 class="title text-center"><?php echo $locations[$locId]->loc_name?></h2>
						<?php foreach($storeProd as $storeId => $cprod){ ?>

						<div class="col-sm-12" id="rec_<?php echo $locId; ?>_store_items_<?php echo $storeId; ?>">
							<!--<h2 class="title text-center"><?php echo $stores[$storeId]->store_name?></h2>-->
							<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr class="title text-center color-grey" ><th colspan="4" ><?php echo $stores[$storeId]->store_name?></th></tr>
									<tr>
										<th>Product</th>
										<th>Product Name</th>
										<th>Product Price</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($cprod as $cproduct){ ?>
									 <tr>
										<td>
											<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" >
											<!--<img width="100px" height="80px" src="<?php echo base_url().'images/products/'.$cproduct->id.'.jpg';?>" alt="" />-->
											</a></p>

										</td>
										<td>
											<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" ><?php echo substr($cproduct->name,0,35).'...';?></a></p>
										</td>
										<td>
											<p><b>$<?php echo $cproduct->price.' ('.$cproduct->quantity.' '.$cproduct->unit.')'?></b></p>
											<p><?php echo '$'.$cproduct->pbase_price.' per '.$cproduct->base_unit;?></p>
										</td>
										<td>
										<p>
											<?php if(isset($cproduct->wid) && $cproduct->wid != ''){ ?>
													<a href="#" onclick="removeFromWishlist(<?php echo $cproduct->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>

												<?php }else{ ?>
													<a href="#" onclick="addToWishlist(<?php echo $cproduct->sp_id;?>)"><i class="fa fa-plus-square"></i>Add to wishlist</a>
												<?php } ?>
											</p>
										</td>


									  </tr>
									 <?php }?>
								</tbody>
								<tfoot>

								</tfoot>
							</table>
						</div>
						<?php } ?>
					</div><!--/recommended_items-->
					<?php }?>
					</div>
					<?php
					}else{ ?>
					<div class="compared_products"><span>This is most cheapest product!!!</span></div>
					<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
