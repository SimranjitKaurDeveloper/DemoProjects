

	<section>
		<div class="container" id="productDetail">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-3">
							<div class="view-product1">
								<img src="<?php echo base_url().'images/products/'.$product->pid.'.jpg';?>" width="200px" height="200px" alt="" />
							
							</div>
						</div>
						<div class="col-sm-9">
							<div class="product-information"><!--/product-information-->
								<!--<img src="images/products/18.jpg" class="newarrival" alt="" />-->
								<span>
										<span>$<?php echo $product->price; ?> (<?php echo $product->quantity; ?> <?php echo $product->unit; ?>)</span>
								</span>
								<h2><?php echo $product->name; ?></h2>
								<p><b>Category:</b><?php echo $categories[$product->cat_id]->cat_name; ?></p>
									<p><b>Store:</b><?php echo $stores[$product->store_id]->store_name; ?></p>
									<p><b>Location:</b><?php echo $locations[$product->loc_id]->loc_name; ?></p>
								
								
								<!--<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>-->
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->

					<?php /*<div class="category-tab shop-details-tab"><!--category-tab-->
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#details" data-toggle="tab">Details</a></li>
								<li><a href="#compareproducts" data-toggle="tab">Compare Product</a></li>
								<!--<li><a href="#tag" data-toggle="tab">Tag</a></li>-->
								<li><a href="#reviews" data-toggle="tab">Reviews (5)</a></li>
							</ul>
						</div>
						<div class="tab-content">
							<div class="tab-pane fade extra active in" id="details">
								<div class="col-sm-12">
									<ul>
									<li><a href=""><i class="fa fa-user"></i>Coles</a></li>
									<li><a href=""><i class="fa fa-calendar-o"></i>1 APRIL 2018</a></li>
									</ul>
									<p><?php echo $product->description; ?></p>
								</div>
							</div>

							<div class="tab-pane fade extra" id="compareproducts">
								<div class="col-sm-12">

									<form action="#">
										<span>
											<input type="text" placeholder="Price"/>
											<input type="text" placeholder="Quantity"/>
											<input type="text" placeholder="Units"/>
											<button type="button" class="btn btn-default pull-right">
											Compare Price
											</button>
										</span>

									</form>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<h2>$12.75</h2>
												<p>Cold Power Powder 2kg</p>
												<h4>Woolworth</h4>
											</div>

										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">

												<h2>$13</h2>
												<p>Cold Power Powder 2kg</p>
												<h4>Aldi</h4>
											</div>

										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">

												<h2>$12.50</h2>
												<p>Cold Power Powder 2kg</p>
												<h4>Country Grower</h4>
											</div>

										</div>
									</div>
								</div>

							</div>


							<div class="tab-pane fade" id="reviews" >
								<div class="col-sm-12">
									<ul>
										<li><a href=""><i class="fa fa-user"></i>EUGEN</a></li>
										<li><a href=""><i class="fa fa-clock-o"></i>12:41 PM</a></li>
										<li><a href=""><i class="fa fa-calendar-o"></i>1 APRIL 2018</a></li>
									</ul>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
									<p><b>Write Your Review</b></p>

									<form action="#">
										<span>
											<input type="text" placeholder="Your Name"/>
											<input type="email" placeholder="Email Address"/>
										</span>
										<textarea name="" ></textarea>
										<b>Rating: </b> <img src="images/product-details/rating.png" alt="" />
										<button type="button" class="btn btn-default pull-right">
											Submit
										</button>
									</form>
								</div>
							</div>

						</div>
					</div><!--/category-tab-->*/ ?>

					<?php 
					$cheaperProd = array_filter($cheaperProd);

					if(!empty($cheaperProd)){ ?>
					<div class="compared_products">
						<span>OTHER PRODUCTS WITH LESS PRICE</span>
					<?php
					foreach($cheaperProd as $locId => $storeProd){ ?>

					<div class="recommended_items col-sm-12" id="rec_loc_items_<?php echo $locId; ?>"><!--recommended_items-->
						<h2 class="title text-center"><?php echo $locations[$locId]->loc_name?></h2>
						<?php foreach($storeProd as $storeId => $cprod){ ?>
							
							<div class="col-sm-12" id="rec_store_items_<?php echo $storeId; ?>">
							<h2 class="title text-center"><?php echo $stores[$storeId]->store_name?></h2>
								<?php foreach($cprod as $cproduct){ ?>
								
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
												<div class="productinfo text-center">
													<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" >
														<img width="200px" height="200px" src="<?php echo base_url().'images/products/'.$cproduct->id.'.jpg';?>" alt="" />
													</a></p>
													
													<h2>$<?php echo $cproduct->price.' ('.$cproduct->quantity.' '.$cproduct->unit.')'?></h2>
													<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" ><?php echo substr($cproduct->name,0,35).'...';?></a></p>
													<p><?php echo $stores[$cproduct->store_id]->store_name;?></p>											
												</div>
												<!--
												<div class="product-overlay">
													<div class="overlay-content">
														<h2><?php echo $product->price;?></h2>
														<p><a href="<?php echo base_url().'/products/view/'.$product->pid;?>" ><?php echo $product->name;?></a></p>
														
													</div>
												</div>-->
										</div>
										<div class="choose">
											<ul class="nav nav-pills nav-justified">
												<li>
												<?php if(isset($cproduct->wid) && $cproduct->wid != ''){ ?>
													<a href="#" onclick="removeFromWishlist(<?php echo $cproduct->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>
													
												<?php }else{ ?>
													<a href="#" onclick="addToWishlist(<?php echo $cproduct->sp_id;?>)"><i class="fa fa-plus-square"></i>Add to wishlist</a>
												<?php } ?>
												</li>
												<!--<li><a href="<?php echo base_url('/products/view/'.$cproduct->sp_id); ?>"><i class="fa fa-plus-square"></i>Add to compare</a></li>-->
												
											</ul>
										</div>
									</div>
								</div>
								<?php } ?>
							</div>
						<?php } ?>
						
						<!--
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
							<?php $total_prod_in_one_loc = count($cprod);
								$total_slider = floor($total_prod_in_one_loc/4);
								for($slidePanel = 1; $slidePanel<=$total_slider; $slidePanel++){
								?>
								<div class="item active">

									<?php foreach($cprod as $cpkey => $cpval){ ?>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php echo base_url('images/products/12.jpg');?>" alt="" />
													<h2><?php echo $cpval->price ?></h2>
													<p><?php echo $cpval->name ?></p>

												</div>
											</div>
										</div>
									</div>
									<?php } ?>
								</div>
								<?php } ?>
								
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>
						</div>-->
					</div><!--/recommended_items-->
					<?php }?>
					</div>
					<?php
					}else{ ?> 
					<div class="compare_products"><span>This is most cheapest product!!!</span></div>
					<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<script type="text/javascript">
function searchloc_items(){ 
	$.each($("input[name='plocation']:checked"), function(){            
               value = $(this).val();//alert(value);
			$('#rec_items_'+value).show();
     });
	$.each($("input[name='plocation']:not(:checked)"), function(){            
               value = $(this).val();//alert(value);
			$('#rec_items_'+value).hide();
     });
	
}
searchloc_items();
function searchstore_items(){ 
	$.each($("input[name='sstore']:checked"), function(){            
               value = $(this).val();//alert(value);
			$('#rec_store_items_'+value).show();
     });
	$.each($("input[name='sstore']:not(:checked)"), function(){            
               value = $(this).val();//alert(value);
			$('#rec_store_items_'+value).hide();
     });
	
}
searchstore_items();
</script>
