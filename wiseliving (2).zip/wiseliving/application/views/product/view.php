

	<section>
		<div class="container" id="productDetail">
			<div class="row">
				<div class="col-sm-3">
					<?php if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>

				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-3">
							<div class="view-product1">
								<img src="<?php echo base_url().'images/products/'.$product->image;?>" width="200px" height="200px" alt="" />

							</div>
						</div>
						<div class="col-sm-9">
							<div class="product-information"><!--/product-information-->
								<!--<img src="images/products/18.jpg" class="newarrival" alt="" />-->
								<span>
										<span>$<?php echo $product->price; ?> (<?php echo $product->quantity; ?> <?php echo $product->unit; ?>)</span>
								</span>
								<h2><?php echo $product->name; ?></h2>
								<span class="baseprice" ><b><?php echo '$'.$product->pbase_price.' per '.$this->productUnitOptions[$product->base_unit];?></b></span>
								<p><b>Category: </b><?php echo $categories[$product->cat_id]->cat_name; ?></p>
								<p><b>Store: </b><?php echo $stores[$product->store_id]->store_name; ?></p>
								<p><b>Location: </b><?php echo $locations[$product->loc_id]->loc_name; ?></p>

								<?php
								//print_r($product);echo $userID;
								 if(isset($product->wid) && $product->wid != '' && $userID == $product->wuid ){ ?>
									<a href="#" onclick="removeFromWishlist(<?php echo $product->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>

								<?php }else{ ?>
									<a href="#" onclick="addToWishlist(<?php echo $product->sp_id;?>)"><i class="fa fa-plus-square"></i>Add to wishlist</a>
								<?php } ?>
								<!--<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>-->
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->


					<?php
					$cheaperProd = array_filter($cheaperProd);

					if(!empty($cheaperProd)){ ?>
					<div class="compared_products">
						<span>OTHER SIMILAR PRODUCTS WITH CHEAPEST PRICE YOU MIGHT BE INTERESTED IN</span>
					<?php
					foreach($cheaperProd as $locId => $storeProd){ ?>

					<div class="recommended_items col-sm-12" id="rec_loc_items_<?php echo $locId; ?>"><!--recommended_items-->
						<!--<div class="recommended_items col-sm-12" id="rec_loc_items_<?php //echo $locId; ?>"><!--recommended_items-->
							<h2 class="title text-center"><?php echo $locations[$locId]->loc_name?></h2>
							<?php foreach($storeProd as $storeId => $cprod){ ?>
							<?php foreach($cprod as $cproduct){ ?>

									<div class="col-sm-3 <?php echo 'store_'.$locId.'_item_'.$cproduct->store_id; ?>">
										<div class="product-image-wrapper">
											<div class="single-products">
													<div class="productinfo text-center">
														<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" >
															<img width="200px" height="200px" src="<?php echo base_url().'images/products/'.$cproduct->image;?>" alt="" />
														</a></p>

														<h2>$<?php echo $cproduct->price.' ('.$cproduct->quantity.' '.$cproduct->unit.')'?></h2>
														<p><a href="<?php echo base_url().'products/view/'.$cproduct->sp_id;?>" ><?php echo substr($cproduct->name,0,35).'...';?></a></p>
														<p><?php echo $stores[$cproduct->store_id]->store_name;?></p>
														<p><span class="baseprice"><b><?php echo '$'.$cproduct->pbase_price.' per '. $this->productUnitOptions[$product->base_unit];?></b></span></p>
													</div>
													<!--
													<div class="product-overlay">
														<div class="overlay-content">
															<h2><?php //echo $product->price;?></h2>
															<p><a href="<?php //echo base_url().'/products/view/'.$product->pid;?>" ><?php //echo $product->name;?></a></p>

														</div>
													</div>-->
											</div>
											<div class="choose">
												<ul class="nav nav-pills nav-justified">
													<li>
														<?php
														//	print_r($product);echo $userID;
														 if(isset($cproduct->wid) && $cproduct->wid != '' && $userID == $cproduct->wuid ){ ?>
															<a href="#" onclick="removeFromWishlist(<?php echo $cproduct->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>

														<?php }else{ ?>
															<a href="#" onclick="addToWishlist(<?php echo $cproduct->sp_id;?>)"><i class="fa fa-plus-square"></i>Add to wishlist</a>
														<?php } ?>
														</li>
													<!--<li><a href="<?php echo base_url('/products/view/'.$cproduct->sp_id); ?>"><i class="fa fa-plus-square"></i>Add to compare</a></li>-->

												</ul>
											</div>
										</div>
									</div>
									<?php } ?>
								<?php } ?>
					</div><!--/recommended_items-->
					<?php }?>
					</div>
					<?php
					}else{ ?>
					<div class="compared_products"><span>This is most cheapest product!!!</span></div>
					<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script type="text/javascript">
	function searchloc_items(){
		$.each($("input[name='plocation']:checked"), function(){
	               value = $(this).val();
				$('#rec_loc_items_'+value).show();
	     });
		$.each($("input[name='plocation']:not(:checked)"), function(){
	               value = $(this).val();
				$('#rec_loc_items_'+value).hide();
	     });

	}
	searchloc_items();
	/*function searchstore_items(){
		$.each($("input[name='plocation']:checked"), function(){
	               locvalue = $(this).val();//alert(locvalue);
			$.each($("input[name='sstore']:checked"), function(){
					   value = $(this).val();//alert(value);
					$('#rec_'+locvalue+'_store_items_'+value).show();
			 });
			 $.each($("input[name='sstore']:not(:checked)"), function(){
	               value = $(this).val();//alert(value);
				$('#rec_'+locvalue+'_store_items_'+value).hide();
			});
		});*/
	  function searchstore_items(){
	  	$.each($("input[name='plocation']:checked"), function(){
	                 locvalue = $(this).val();//alert(locvalue);
	  		$.each($("input[name='sstore']:checked"), function(){
	  				   value = $(this).val();//alert(value);
	  				$('.store_'+locvalue+'_item_'+value).show();
	  		 });
	  		 $.each($("input[name='sstore']:not(:checked)"), function(){
	                 value = $(this).val();//alert(value);
	  				$('.store_'+locvalue+'_item_'+value).hide();
	  		});
	  	});
	   }
	searchstore_items();
</script>
	<!-- js is implementing in header.php-->
	<script type="text/javascript">
		function addToWishlist(id)
        {
          //Ajax Load data from ajax
					uid = "";
					uid = "<?php echo $userID;?>";
				if(uid == "0"){
						window.location = "<?php echo site_url('auth/login')?>";
				}else{


          $.ajax({
            url : "<?php echo site_url('products/addToWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
							if(data.status){
									if(data.status == 'success'){	alert("Product added in the wishlist.");
									}else if(data.status == 'failure'){ alert("Product already in the wishlist.");
									}else{ alert('Product not added in wishlist');

									}

							}else{
								alert('Product not added in wishlist, error occurs');

							}
								location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
							console.warn(jqXHR.responseText);
							console.warn(jqXHR);
							alert(errorThrown);
						}
         });
}

        }
		function removeFromWishlist(id)
        {
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('products/removeFromWishlist')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
									if(data.status == 'success'){	alert("Product removed from wishlist.");
									}else if(data.status == 'failure'){	alert("Product not removed from wishlist.");

									}else{ alert('error');
									}
									location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
								console.warn(jqXHR.responseText);
								console.warn(jqXHR);
								alert(errorThrown);
							}
         });


        }



  </script>
