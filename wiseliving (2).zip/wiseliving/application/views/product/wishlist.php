<?php //print_r($products);die;?>
<section id="advertisement">
		<div class="container">
			<img src="images/shop/advertisement.jpg" alt="" />
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row">
				<!--<div class="col-sm-3">
					<?php //if(isset($leftSidebar)){	$this->view($leftSidebar); }?>
				</div>-->

				<div class="col-sm-12 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Wishlist List</h2>
						<?php foreach($products as $product){?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<p><a href="<?php echo base_url().'products/view/'.$product->sp_id;?>" >
										<img src="<?php echo base_url().'images/products/'.$product->image;?>" width="200px" height="200px" />
										</a></p>

										<h2><?php echo '$'.$product->price.' ('.$product->quantity.''.$product->unit.')';?></h2>
										<p><a href="<?php echo base_url().'products/view/'.$product->sp_id;?>" >
										<?php echo substr($product->name,0,35).'...';?></a></p>
										<p><?php echo $stores[$product->store_id]->store_name.', '.$locations[$product->loc_id]->loc_name;?></p>
										<p><b><?php echo '$'.$product->pbase_price.' per '.$product->base_unit;?></b></p>
									</div>

								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li>
											<a href="#" onclick="removeFromWishlist(<?php echo $product->wid;?>)"><i class="fa fa-plus-square"></i>Remove from wishlist</a>

										</li>

									</ul>
								</div>
							</div>
						</div>
						<?php } ?>

						<!--<ul class="pagination">
							<li class="active"><a href="">1</a></li>
							<li><a href="">2</a></li>
							<li><a href="">3</a></li>
							<li><a href="">&raquo;</a></li>
						</ul>-->
					</div><!--features_items-->

				</div>
			</div>
		</div>
	</section>
	<script type="text/javascript">
		function removeFromWishlist(id)
				{
					//Ajax Load data from ajax
					$.ajax({
						url : "<?php echo site_url('products/removeFromWishlist')?>/" + id,
						type: "GET",
						dataType: "JSON",
						success: function(data)
						{
									if(data.status == 'success'){	alert("Product removed from wishlist.");
									}else if(data.status == 'failure'){	alert("Product not removed from wishlist.");

									}else{ alert('error');
									}
									location.reload();
						},
						error: function (jqXHR, textStatus, errorThrown)
						{
								console.warn(jqXHR.responseText);
								console.warn(jqXHR);
								alert(errorThrown);
							}
				 });


				}



	</script>
