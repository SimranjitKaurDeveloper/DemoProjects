<?php $this->view('templates/header'); ?>
<?php if(isset($viewName)){	$this->view($viewName); }?>
<?php $this->view('templates/footer'); ?>