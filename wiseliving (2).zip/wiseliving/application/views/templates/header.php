<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>WiseLiving</title>
    <link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/price-range.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <!--<link rel="shortcut icon" href="<?php echo base_url(); ?>images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url(); ?>images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url(); ?>images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url(); ?>images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url(); ?>images/ico/apple-touch-icon-57-precomposed.png">
-->


    <script src="<?php echo base_url(); ?>js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
	  <script src="<?php echo base_url(); ?>js/jquery.scrollUp.min.js"></script>
	  <script src="<?php echo base_url(); ?>js/price-range.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url(); ?>js/main.js"></script>


    <script type="text/javascript">
		function insertParam(key, value)
		{
  			key = encodeURI(key); value = encodeURI(value);
        var kvp = document.location.search.substr(1).split('&');

  			var i=kvp.length; var x; while(i--)
  			{
    				x = kvp[i].split('=');
              if (x[0]==key)
    				{
    					x[1] = value;
    					kvp[i] = x.join('=');
    					break;
    				}
			   }

			   if(i<0) {kvp[kvp.length] = [key,value].join('=');}

  			 if(key == 'sitem' || key == 'sloc'){
    				getUrl = "<?php echo site_url('products/?')?>"+kvp.join('&');
    				window.location = getUrl;
    			}else{	document.location.search = kvp.join('&');
    			}
		}


	/* $(document).ready(function(){
		$('#search').click(function() {
			alert('kk');
			var search_item = $('#search_item').val();
			var search_loc = $('#search_loc').val();
			if (search_item != undefined && search_item != null && search_loc != undefined && search_loc != null) {
				window.location = '/products?item=' + search_item + '&loc='+search_loc;
			}else{
				alert('Please search by both tag and location');
			}
		})

		});​*/

	</script>


</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +2 95 01 88 821</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@domain.com</a></li>
								<?php if (!$this->ion_auth->logged_in()){  ?>
									<li><a href="<?php echo base_url().'register'; ?>"><i class="fa fa-envelope"></i>Register</a></li>
									<?php } ?>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->

		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="<?php echo base_url();?>"><img src="<?php echo base_url(); ?>images/home/logo.png" alt="" /></a>
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<?php if ($this->ion_auth->is_admin()){ ?>
									<li><a href="<?php echo base_url().'auth'; ?>" >Manage Users</a></li>
									<li><a href="<?php echo base_url().'products/listing'; ?>" >Manage Products</a></li>
								<?php } ?>
								<?php if ($this->ion_auth->logged_in()){
									$user = $this->ion_auth->user()->row();
								?>
									<li><a href="<?php echo base_url().'auth/edit_user/'.$user->id;?>"><i class="fa fa-user"></i> Account</a></li>
								<?php } ?>
									<li><a href="<?php echo base_url().'products/wishlist'; ?>"><i class="fa fa-star"></i> Wishlist</a></li>
								<?php if (!$this->ion_auth->logged_in()){ ?>
									<li><a href="<?php echo base_url().'auth/login';?>"><i class="fa fa-lock"></i>Login</a></li>
								<?php }else{ ?>
									<li><a href="<?php echo base_url().'auth/logout';?>"><i class="fa fa-lock"></i>Logout</a></li>
								<?php } ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->

		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="<?php echo base_url(); ?>">Home</a></li>
								<li><a href="<?php echo base_url().'products'; ?>" class="active">Products</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">

						<!--<form action="<?php echo base_url('/products');?>" id="searchform" class="form-horizontal custom-form">-->
						<div class="search_box pull-right">
							<input type="text" name="sitem" id="search_item" onchange="insertParam(this.name,this.value);" value="<?php if(isset($_GET['sitem'])){echo $_GET['sitem'];}?>" placeholder="Search by title or description like apple, juice"/>
						</div>
						<div class="search_box pull-right">
							<input type="text" name="sloc" id="search_loc" onchange="insertParam(this.name,this.value);" value="<?php if(isset($_GET['sloc'])){echo $_GET['sloc'];}?>" placeholder="Search by location with pincode like 2150"/>
						</div>
						<!--<button type="submit" name="search" value="1" />Go</button>
						</form>-->

					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
