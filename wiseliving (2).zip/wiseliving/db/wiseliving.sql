-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2018 at 05:13 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wiseliving`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) UNSIGNED NOT NULL,
  `cat_name` varchar(45) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cat_name`, `active`) VALUES
(1, 'Fruits', 1),
(2, 'Vegetables', 1),
(3, 'Bakery', 1),
(4, 'Freezer', 1),
(5, 'Drinks', 1),
(6, 'Meat and Seafood', 1),
(7, 'Desserts and  sweets', 1),
(8, 'Baby', 1),
(9, 'Dairy', 1),
(10, 'Snacks', 1),
(11, 'Household Items', 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User'),
(3, 'merchant', 'the one who creates products'),
(4, 'customer', 'the one who search group');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `lid` int(11) UNSIGNED NOT NULL,
  `loc_name` varchar(20) NOT NULL,
  `loc_pincode` int(6) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`lid`, `loc_name`, `loc_pincode`, `active`) VALUES
(1, 'Parramatta', 2150, 1),
(2, 'Westmead', 2145, 1),
(3, 'Wentworthville', 2145, 1),
(4, 'Auburn', 2144, 0),
(5, 'Homebush', 2140, 0),
(6, 'Strathfield', 2135, 0),
(7, 'Toongabbie', 2146, 0),
(8, 'Blacktown', 2148, 0),
(9, 'Northmead', 2152, 0),
(10, 'Castle Hill', 2154, 0),
(11, 'Granville', 2142, 0),
(12, 'Merrylands', 2160, 0);

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `base_qty` float NOT NULL,
  `base_unit` enum('kg','l') NOT NULL,
  `cat_id` int(11) UNSIGNED DEFAULT NULL,
  `tags` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `base_qty`, `base_unit`, `cat_id`, `tags`, `image`, `created_date`, `modified_date`) VALUES
(1, 'Weet-Bix Go Apple Cinnamon Breakfast Biscuits', 'Etiam vulputate venenatis tortor sit amet maximus. Suspendisse potenti. Cras porta, magna feugiat luctus sollicitudin, lorem tellus rhoncus odio, vel ornare nisl velit sit amet lorem. Proin auctor lacus orci, aliquet lobortis sem dictum ac. Vivamus mi leo, tincidunt id tristique eget, commodo et eli', 1, 'kg', 3, '', 'b1.jpg', '2018-06-03 14:53:17', '2018-06-03 14:53:17'),
(2, 'Family Assorted Biscuits', 'Fusce rutrum nisl felis, condimentum rutrum erat vestibulum ac. Sed massa dolor, malesuada vel ex nec, dignissim auctor turpis.', 1, 'kg', 3, '', 'b4.jpg', '2018-06-03 14:54:54', '2018-06-03 14:54:54'),
(4, 'Assorted Creams Biscuits', 'Mauris pulvinar sem enim, quis ornare metus gravida eget. Vivamus ornare imperdiet metus vitae malesuada. Duis tellus est, vehicula at varius sit amet, aliquam et turpis. Integer eget est orci.', 1, 'kg', 3, '', 'b8.jpg', '2018-06-03 15:43:39', '2018-06-03 15:43:39'),
(6, 'Mint Slice Chocolate Biscuits Value Pack', 'Pellentesque feugiat ligula cursus turpis accumsan, a varius lorem facilisis. Fusce cursus venenatis felis quis dapibus. Morbi ultrices purus non massa suscipit, vel faucibus nisi consectetur. Ut in libero quis mauris sodales feugiat maximus sed massa.', 1, 'kg', 3, '', 'b10.jpg', '2018-06-03 16:01:05', '2018-06-03 16:01:05'),
(7, 'Weet-Bix Go Wildberry Breakfast Biscuits', 'Etiam vitae magna ac erat rhoncus dictum ac at ipsum. Nam at volutpat ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas at neque massa. Morbi eget sapien nec diam varius accumsan. Nulla facilisi. Integer faucibus id turpis eget aliquet', 1, 'kg', 3, '', 'b2.jpg', '2018-06-03 16:02:25', '2018-06-03 16:02:25'),
(9, 'Chocolate Hershey Syrup', '		Curabitur nec sem nec odio hendrerit lacinia. Cras sed nulla ut tellus gravida interdum et id ligula. Proin maximus mi sagittis lectus mattis, ac viverra augue porta. Mauris pulvinar sem enim, quis ornare metus gravida eget. Vivamus ornare imperdiet metus vitae malesuada. Duis tellus est, vehicula', 1, 'l', 5, '', 'hershey.png', '2018-11-22 17:30:16', '2018-11-22 17:30:16'),
(10, 'Moove Chocolate Drink', 'Suspendisse potenti. Suspendisse et dui libero. Nullam vulputate accumsan augue id eleifend. Etiam vitae magna ac erat rhoncus dictum ac at ipsum. Nam at volutpat ante. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Maecenas at neque massa. Morbi eget sapien ', 1, 'l', 5, '', 'moove.jpg', '2018-11-22 18:48:08', '2018-11-22 18:48:08'),
(11, 'Nutrella', 'Praesent ut lobortis leo, in dignissim mauris. In suscipit lectus ac placerat suscipit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus egestas odio id faucibus eleifend. Vivamus cursus augue at euismod tincidunt. Vivamus congue venenatis dignissim. Ut', 1, 'kg', 8, '', 'nutella.jpg', '2018-11-23 11:54:42', '2018-11-23 11:54:42'),
(12, 'Caramel IceCream', 'Cras vitae ornare arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent eu eros volutpat, tempor nibh vitae, rutrum dui. In augue leo, suscipit quis iaculis sed, euismod et quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer faucibus', 1, 'l', 7, '', 'caramel.jpg', '2018-11-23 11:57:55', '2018-11-23 11:57:55'),
(13, 'Moove Chocolate Drink 600ml', 'In augue leo, suscipit quis iaculis sed, euismod et quam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer faucibus lacinia hendrerit. Fusce rutrum nisl felis, condimentum rutrum erat vestibulum ac. Sed massa dolor, malesuada vel ex nec, dignissim auctor turpis.', 1, 'l', 5, '', 'cmoove4.jpg', '2018-11-23 13:29:22', '2018-11-23 13:29:22');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `roles_name` varchar(45) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `storeold`
--

CREATE TABLE `storeold` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `street` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `sid` int(11) UNSIGNED NOT NULL,
  `store_name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`sid`, `store_name`, `active`) VALUES
(1, 'Coles', 1),
(2, 'Aldi', 1),
(3, 'The Groves Australia', 0),
(4, 'Rathe', 0),
(5, 'Woolworths', 1),
(6, 'Big W', 0),
(7, 'Caltex', 0),
(8, 'Metcash', 0),
(9, 'Harris Farm', 0),
(10, 'Country Growers', 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_products`
--

CREATE TABLE `store_products` (
  `sp_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `loc_id` int(11) UNSIGNED NOT NULL,
  `store_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` enum('ml','l','g','kg') NOT NULL,
  `pbase_price` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_products`
--

INSERT INTO `store_products` (`sp_id`, `user_id`, `loc_id`, `store_id`, `product_id`, `price`, `quantity`, `unit`, `pbase_price`, `created_date`, `modified_date`) VALUES
(1, 1, 1, 1, 1, 2, 250, 'g', 8, '2018-06-03 14:53:17', '0000-00-00 00:00:00'),
(2, 1, 1, 1, 2, 5, 500, 'g', 10, '2018-06-03 14:54:54', '2018-06-03 14:54:54'),
(4, 1, 1, 5, 4, 3, 500, 'g', 6, '2018-06-03 15:43:39', '2018-06-03 15:43:39'),
(6, 1, 2, 1, 6, 4, 337, 'g', 12, '2018-06-03 16:01:05', '0000-00-00 00:00:00'),
(7, 1, 2, 5, 7, 3, 250, 'g', 10, '2018-06-03 16:02:25', '2018-06-03 16:02:25'),
(9, 1, 2, 1, 1, 5, 250, 'g', 20, '2018-06-03 18:16:59', '2018-06-03 18:16:59'),
(10, 6, 1, 5, 9, 5, 800, 'ml', 6, '2018-11-22 17:30:16', '2018-11-22 17:30:16'),
(11, 6, 1, 5, 10, 4, 300, 'ml', 13, '2018-11-22 18:48:08', '2018-11-22 18:48:08'),
(12, 6, 1, 1, 10, 4.5, 300, 'ml', 15, '2018-11-23 11:17:40', '0000-00-00 00:00:00'),
(13, 6, 1, 5, 11, 11, 270, 'g', 41, '2018-11-23 11:54:42', '0000-00-00 00:00:00'),
(14, 6, 1, 1, 12, 12, 950, 'ml', 13, '2018-11-23 11:57:55', '2018-11-23 11:57:55'),
(15, 6, 2, 1, 12, 12, 1, 'l', 12, '2018-11-23 12:25:12', '2018-11-23 12:25:12'),
(16, 6, 3, 5, 12, 11, 1, 'l', 11, '2018-11-23 12:38:06', '2018-11-23 12:38:06'),
(17, 6, 1, 5, 13, 5.5, 600, 'ml', 9, '2018-11-23 13:29:22', '2018-11-23 13:29:22'),
(18, 6, 1, 2, 13, 6, 600, 'ml', 10, '2018-11-23 13:30:47', '2018-11-23 13:30:47'),
(19, 6, 1, 2, 2, 5.65, 500, 'g', 11, '2018-11-23 13:57:23', '2018-11-23 13:57:23'),
(20, 6, 2, 5, 2, 4.95, 500, 'g', 10, '2018-11-23 13:58:21', '2018-11-23 13:58:21'),
(21, 6, 2, 1, 10, 4, 300, 'ml', 13, '2018-11-23 14:00:19', '2018-11-23 14:00:19'),
(22, 6, 1, 1, 7, 4, 250, 'g', 16, '2018-11-26 15:01:41', '2018-11-26 15:01:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, NULL, 1268889823, 1527998009, 1, 'Admin', 'istrator', 'ADMIN', '0'),
(2, '::1', 'simranjitkaur161288@gmail.com', '$2y$08$k3ZMRnkY/c./c/VWxDmRcOxVnDN36JxAmQ/UyR0y4PmwM.F4SBLM2', NULL, 'simranjitkaur161288@gmail.com', NULL, NULL, NULL, NULL, 1525516887, 1525572491, 1, 'simranjit', 'kaur', 'test', '0470665500'),
(3, '::1', 'simmikaur', '$2y$08$wzcZnWYyODWonKMkBHR3jeI.BSq0RopdSWOHURWnbHHlf3SFHSImm', NULL, 's@s.com', NULL, NULL, NULL, NULL, 1527990399, 1528075674, 1, 'simmi', 'kaur', 'test', 'test'),
(4, '::1', 'simkaur', '$2y$08$GZ5hRuiQpO91CkJLCsA.oujRLAjz/yR2ATcZxfJHzJRnxj2dHgdS6', NULL, 's@sim.com', NULL, NULL, NULL, NULL, 1527991057, 1527991115, 1, 'sim', 'kaur', NULL, NULL),
(5, '::1', 'wwwkaur', '$2y$08$3zxZ6uLCX1dpqoADK7IJu.vQqHfE42cHB5hF/xUeHCg3FfU0PbxHS', NULL, 'www@kaur.com', NULL, NULL, NULL, NULL, 1527991249, 1528027841, 1, 'www', 'kaur', 'test', 'test'),
(6, '::1', 'Tester', '$2y$08$lVJ4iTTIEc0V6Fn2z3RhpOWrHWAk3NwbWqxA7Pr0Q/qpW0kfNgjTu', NULL, 'sim@sim.com', NULL, NULL, NULL, NULL, 1542866674, 1543204707, 1, 'Test', 'kaur', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usersold`
--

CREATE TABLE `usersold` (
  `id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email_id` varchar(45) NOT NULL,
  `location` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_date` date NOT NULL,
  `roleid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(6, 3, 4),
(4, 4, 4),
(7, 5, 4),
(8, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wishlistold`
--

CREATE TABLE `wishlistold` (
  `productid` int(11) NOT NULL,
  `productcode` int(11) NOT NULL,
  `productname` varchar(45) NOT NULL,
  `productdesc` varchar(45) NOT NULL,
  `productprice` float NOT NULL,
  `productunit` varchar(45) DEFAULT NULL,
  `productqty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlistold`
--

INSERT INTO `wishlistold` (`productid`, `productcode`, `productname`, `productdesc`, `productprice`, `productunit`, `productqty`) VALUES
(4, 0, '', '', 0, NULL, NULL),
(11, 787, 'Nal', 'jkljl', 15, 'mg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` int(11) UNSIGNED NOT NULL,
  `storeproduct_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `storeproduct_id`, `user_id`) VALUES
(1, 1, 1),
(3, 4, 1),
(7, 6, 5),
(13, 6, 3),
(14, 4, 3),
(16, 2, 3),
(18, 1, 3),
(29, 9, 3),
(30, 12, 6),
(31, 11, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `storeold`
--
ALTER TABLE `storeold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_userid` (`userid`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `store_products`
--
ALTER TABLE `store_products`
  ADD PRIMARY KEY (`sp_id`),
  ADD KEY `FK_loc` (`loc_id`),
  ADD KEY `FK_store` (`store_id`),
  ADD KEY `FK_user` (`user_id`),
  ADD KEY `FK_product` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usersold`
--
ALTER TABLE `usersold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_roleid` (`roleid`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- Indexes for table `wishlistold`
--
ALTER TABLE `wishlistold`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `FK_storeproduct` (`storeproduct_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `lid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `storeold`
--
ALTER TABLE `storeold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `sid` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `store_products`
--
ALTER TABLE `store_products`
  MODIFY `sp_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usersold`
--
ALTER TABLE `usersold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cid`);

--
-- Constraints for table `storeold`
--
ALTER TABLE `storeold`
  ADD CONSTRAINT `FK_userid` FOREIGN KEY (`userid`) REFERENCES `usersold` (`id`);

--
-- Constraints for table `store_products`
--
ALTER TABLE `store_products`
  ADD CONSTRAINT `FK_loc` FOREIGN KEY (`loc_id`) REFERENCES `locations` (`lid`),
  ADD CONSTRAINT `FK_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `FK_store` FOREIGN KEY (`store_id`) REFERENCES `stores` (`sid`),
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `usersold`
--
ALTER TABLE `usersold`
  ADD CONSTRAINT `FK_roleid` FOREIGN KEY (`roleid`) REFERENCES `roles` (`id`);

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `FK_storeproduct` FOREIGN KEY (`storeproduct_id`) REFERENCES `store_products` (`sp_id`),
  ADD CONSTRAINT `wishlists_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
